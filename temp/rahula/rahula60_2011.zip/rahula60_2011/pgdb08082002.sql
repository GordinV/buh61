-- Database: buhdata5
CREATE DATABASE "buhdata5" WITH ENCODING = 'WIN';

