IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'buhdata5')
	DROP DATABASE [buhdata5]
GO

CREATE DATABASE [buhdata5]  ON (NAME = N'buhdata5_Data', FILENAME = N'c:\mssql7\data\buhdata5_data.mdf' , SIZE = 41, FILEGROWTH = 10%) LOG ON (NAME = N'buhdata5_Log', FILENAME = N'C:\MSSQL7\data\buhdata5_Log.LDF' , SIZE = 2146, FILEGROWTH = 10%)
 COLLATE SQL_Latin1_General_CP1251_CI_AS
GO

exec sp_dboption N'buhdata5', N'autoclose', N'true'
GO

exec sp_dboption N'buhdata5', N'bulkcopy', N'false'
GO

exec sp_dboption N'buhdata5', N'trunc. log', N'false'
GO

exec sp_dboption N'buhdata5', N'torn page detection', N'false'
GO

exec sp_dboption N'buhdata5', N'read only', N'false'
GO

exec sp_dboption N'buhdata5', N'dbo use', N'false'
GO

exec sp_dboption N'buhdata5', N'single', N'false'
GO

exec sp_dboption N'buhdata5', N'autoshrink', N'true'
GO

exec sp_dboption N'buhdata5', N'ANSI null default', N'false'
GO

exec sp_dboption N'buhdata5', N'recursive triggers', N'false'
GO

exec sp_dboption N'buhdata5', N'ANSI nulls', N'false'
GO

exec sp_dboption N'buhdata5', N'concat null yields null', N'false'
GO

exec sp_dboption N'buhdata5', N'cursor close on commit', N'false'
GO

exec sp_dboption N'buhdata5', N'default to local cursor', N'false'
GO

exec sp_dboption N'buhdata5', N'quoted identifier', N'false'
GO

exec sp_dboption N'buhdata5', N'ANSI warnings', N'false'
GO

exec sp_dboption N'buhdata5', N'auto create statistics', N'true'
GO

exec sp_dboption N'buhdata5', N'auto update statistics', N'true'
GO

use [buhdata5]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_aa]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_aa]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_aa]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_aa]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigD_aa]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigD_aa]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_arv]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_arv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_arv]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_arv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_trig_i_arv1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_trig_i_arv1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_trigD_arv1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_trigD_arv1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_trigU_arv1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_trigU_arv1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_arvtasu]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_arvtasu]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_asutus]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_asutus]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_asutus]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_asutus]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigD_asutus]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigD_asutus]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_GetId_doklausend]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_GetId_doklausend]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getId_doklausHeader]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getId_doklausHeader]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_dokprop]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_dokprop]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_holidays]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_holidays]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_journal]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_journal]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_journal]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_journal]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigD_journal]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigD_journal]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[check_kinnitamine]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[check_kinnitamine]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[check_kinnitamine_for_delete]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[check_kinnitamine_for_delete]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_checksubkonto_journal1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_checksubkonto_journal1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_journal1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_journal1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_kontoinf]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_kontoinf]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_kontoinf]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_kontoinf]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[trigD_kontoinf]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[trigD_kontoinf]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_lausdok]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_lausdok]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CHEK_FOR_JOURNAL1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[CHEK_FOR_JOURNAL1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[check_for_update]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[check_for_update]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_lausend]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_lausend]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_leping1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_leping1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_leping2]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_leping2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_library]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_library]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_library]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_library]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigD_library]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigD_library]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_nomenklatuur]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_nomenklatuur]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_nomenklatuur]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_nomenklatuur]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_nomenklatuur]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_nomenklatuur]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_palk_asutus]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_palk_asutus]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_check_newid]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_check_newid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_palk_config]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_palk_config]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getId_palk_jaak]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getId_palk_jaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_palk_kaart]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_palk_kaart]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_palk_lib]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_palk_lib]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spD_recalk_jaak]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[spD_recalk_jaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spI_recalk_jaak]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[spI_recalk_jaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_palk_taabel1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_palk_taabel1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_palk_taabel2]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_palk_taabel2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_pvkaart]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_pvkaart]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_pv_oper]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_pv_oper]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_rekv]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_rekv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_rekv]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_rekv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigD_rekv]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigD_rekv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_saldo]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_saldo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_saldo]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_saldo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_saldo1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_saldo1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_saldo1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_saldo1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_sorder1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_sorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_sorder1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_sorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigD_sorder1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigD_sorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_sorder2]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_sorder2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_sorder2]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_sorder2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_sorder2]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_sorder2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_subkonto]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_subkonto]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_subkonto]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_subkonto]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_subkonto]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_subkonto]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_tooleping]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_tooleping]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_tuludkulud]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_tuludkulud]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_userid]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_userid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigD_userid]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigD_userid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_userid]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_userid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_vorder1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_vorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigI_vorder1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigI_vorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TrigU_vorder1]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TrigU_vorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_getid_vorder2]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[sp_getid_vorder2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[aa]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[aa]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[aasta]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[aasta]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[arv]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[arv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[arv1]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[arv1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[arvtasu]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[arvtasu]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[asutus]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[asutus]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[dbase]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[dbase]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[doklausend]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[doklausend]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[doklausheader]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[doklausheader]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[dokprop]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[dokprop]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[holidays]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[holidays]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[journal]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[journal]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[journal1]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[journal1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[journal1TMP]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[journal1TMP]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[journalTMP]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[journalTMP]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[kontoinf]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[kontoinf]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ladu_config]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ladu_config]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ladu_grupp]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ladu_grupp]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ladu_jaak]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ladu_jaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ladu_minkogus]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ladu_minkogus]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ladu_oper]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ladu_oper]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ladu_ulehind]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ladu_ulehind]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[lausdok]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[lausdok]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[lausend]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[lausend]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[leping1]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[leping1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[leping2]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[leping2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[leping3]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[leping3]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[library]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[library]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[nomenklatuur]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[nomenklatuur]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_asutus]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_asutus]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_config]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_config]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_jaak]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_jaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_kaart]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_kaart]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_lib]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_lib]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_oper]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_oper]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_taabel1]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_taabel1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[palk_taabel2]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[palk_taabel2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[pv_kaart]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[pv_kaart]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[pv_oper]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[pv_oper]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[raamat]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[raamat]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[rekv]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[rekv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[saldo]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[saldo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[saldo1]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[saldo1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[saldo2]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[saldo2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sorder1]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[sorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sorder2]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[sorder2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[subkonto]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[subkonto]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tooleping]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tooleping]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tuludkulud]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tuludkulud]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[userid]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[userid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vorder1]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[vorder1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vorder2]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[vorder2]
GO

CREATE TABLE [dbo].[aa] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[arve] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[nimetus] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[saldo] [money] NOT NULL ,
	[default_] [smallint] NOT NULL ,
	[kassa] [int] NOT NULL ,
	[pank] [int] NOT NULL ,
	[konto] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[aasta] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[aasta] [smallint] NOT NULL ,
	[KUU] [smallint] NOT NULL ,
	[kinni] [smallint] NOT NULL ,
	[default_] [smallint] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[arv] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[userid] [int] NOT NULL ,
	[journalid] [int] NOT NULL ,
	[doklausid] [int] NOT NULL ,
	[liik] [smallint] NOT NULL ,
	[operid] [int] NOT NULL ,
	[number] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[asutusid] [int] NOT NULL ,
	[arvid] [int] NOT NULL ,
	[lisa] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[tahtaeg] [datetime] NULL ,
	[kbmta] [money] NOT NULL ,
	[kbm] [money] NOT NULL ,
	[summa] [money] NOT NULL ,
	[tasud] [datetime] NULL ,
	[tasudok] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[arv1] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[nomid] [int] NOT NULL ,
	[kogus] [decimal](18, 3) NOT NULL ,
	[hind] [money] NOT NULL ,
	[soodus] [smallint] NOT NULL ,
	[kbm] [money] NOT NULL ,
	[maha] [smallint] NOT NULL ,
	[summa] [money] NOT NULL ,
	[kood1] [int] NOT NULL ,
	[kood2] [int] NOT NULL ,
	[kood3] [int] NOT NULL ,
	[kood4] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[arvtasu] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[arvid] [int] NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[summa] [money] NOT NULL ,
	[dok] [char] (60) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[nomid] [int] NOT NULL ,
	[pankkassa] [smallint] NOT NULL ,
	[journalid] [int] NOT NULL ,
	[sorderid] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[doklausId] [int] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[asutus] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[regkood] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[nimetus] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[omvorm] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[aadress] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kontakt] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[tel] [char] (60) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[faks] [char] (60) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[email] [char] (60) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[dbase] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[alias] [char] (50) COLLATE Cyrillic_General_CI_AS NOT NULL ,
	[lastnum] [int] NOT NULL ,
	[doknum] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[doklausend] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[lausendid] [int] NOT NULL ,
	[percent_] [smallint] NOT NULL ,
	[summa] [money] NOT NULL ,
	[kood1] [int] NOT NULL ,
	[kood2] [int] NOT NULL ,
	[kood3] [int] NOT NULL ,
	[kood4] [int] NOT NULL ,
	[kbm] [smallint] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[doklausheader] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[dok] [char] (50) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[proc_] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[selg] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[dokprop] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[proc_] [varchar] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[KbmlausendId] [int] NOT NULL ,
	[registr] [smallint] NOT NULL ,
	[vaatalaus] [smallint] NOT NULL ,
	[selg] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[holidays] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[kuu] [smallint] NOT NULL ,
	[paev] [smallint] NOT NULL ,
	[nimetus] [varchar] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[journal] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[userid] [int] NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[asutusid] [int] NOT NULL ,
	[selg] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[dok] [char] (60) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[tunnusid] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[dokid] [int] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[journal1] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[lausendid] [int] NOT NULL ,
	[summa] [money] NOT NULL ,
	[dokument] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[kood1] [int] NOT NULL ,
	[kood2] [int] NOT NULL ,
	[kood3] [int] NOT NULL ,
	[kood4] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[journal1TMP] (
	[COPYID] [int] NOT NULL ,
	[id] [int] NOT NULL ,
	[parentid] [int] NOT NULL ,
	[lausendid] [int] NOT NULL ,
	[deebet] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kreedit] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[summa] [money] NOT NULL ,
	[dokument] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[kood1] [int] NOT NULL ,
	[kood2] [int] NOT NULL ,
	[kood3] [int] NOT NULL ,
	[kood4] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[journalTMP] (
	[COPYID] [int] IDENTITY (1, 1) NOT NULL ,
	[id] [int] NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[userid] [int] NOT NULL ,
	[kpv] [datetime] NULL ,
	[asutusid] [int] NOT NULL ,
	[selg] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[dok] [char] (60) COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[tunnusid] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[dokid] [int] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[kontoinf] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[type] [int] NOT NULL ,
	[formula] [int] NOT NULL ,
	[aasta] [float] NOT NULL ,
	[algsaldo] [money] NOT NULL ,
	[liik] [smallint] NOT NULL ,
	[pohikonto] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ladu_config] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[liik] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ladu_grupp] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[nomid] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ladu_jaak] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[dokItemId] [int] NOT NULL ,
	[nomid] [int] NOT NULL ,
	[userid] [int] NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[hind] [money] NOT NULL ,
	[kogus] [decimal](18, 3) NOT NULL ,
	[maha] [decimal](18, 3) NOT NULL ,
	[jaak] [decimal](18, 3) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ladu_minkogus] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[kogus] [money] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ladu_oper] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[nimetus] [varchar] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[liik] [smallint] NOT NULL ,
	[lausendid] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[ladu_ulehind] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[ulehind] [money] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[lausdok] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[dokid] [int] NOT NULL ,
	[lausendid] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[lausend] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[deebet] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kreedit] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[nimetus] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[leping1] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[asutusid] [int] NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[doklausid] [int] NOT NULL ,
	[number] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[tahtaeg] [datetime] NULL ,
	[selgitus] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[dok] [image] NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[leping2] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[nomid] [int] NOT NULL ,
	[kogus] [float] NOT NULL ,
	[hind] [money] NOT NULL ,
	[soodus] [smallint] NOT NULL ,
	[soodusalg] [datetime] NULL ,
	[sooduslopp] [datetime] NULL ,
	[status] [smallint] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[formula] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[leping3] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[algkogus] [decimal](18, 0) NOT NULL ,
	[loppkogus] [decimal](18, 5) NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[library] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[kood] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[nimetus] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[library] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[nomenklatuur] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[doklausid] [int] NOT NULL ,
	[dok] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kood] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[nimetus] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[uhik] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[hind] [money] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_asutus] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvId] [int] NOT NULL ,
	[osakondId] [int] NOT NULL ,
	[ametId] [int] NOT NULL ,
	[kogus] [numeric](18, 2) NOT NULL ,
	[vaba] [numeric](18, 2) NOT NULL ,
	[palgamaar] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_config] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[minpalk] [money] NOT NULL ,
	[tulubaas] [money] NOT NULL ,
	[round] [money] NOT NULL ,
	[jaak] [smallint] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_jaak] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[lepingId] [int] NOT NULL ,
	[kuu] [smallint] NOT NULL ,
	[aasta] [smallint] NOT NULL ,
	[jaak] [money] NOT NULL ,
	[arvestatud] [money] NOT NULL ,
	[kinni] [money] NOT NULL ,
	[tulumaks] [money] NOT NULL ,
	[sotsmaks] [money] NOT NULL ,
	[muud] [money] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_kaart] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[lepingid] [int] NOT NULL ,
	[LibId] [int] NOT NULL ,
	[summa] [money] NOT NULL ,
	[percent_] [smallint] NOT NULL ,
	[tulumaks] [smallint] NOT NULL ,
	[tulumaar] [smallint] NOT NULL ,
	[status] [smallint] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_lib] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[liik] [smallint] NOT NULL ,
	[tund] [smallint] NOT NULL ,
	[maks] [smallint] NOT NULL ,
	[palgafond] [smallint] NOT NULL ,
	[asutusest] [smallint] NOT NULL ,
	[lausendId] [int] NOT NULL ,
	[algoritm] [char] (10) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_oper] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvId] [int] NOT NULL ,
	[libId] [int] NOT NULL ,
	[LepingId] [int] NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[summa] [money] NOT NULL ,
	[doklausId] [int] NOT NULL ,
	[journalId] [int] NOT NULL ,
	[journal1Id] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_taabel1] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[toolepingId] [int] NOT NULL ,
	[kokku] [smallint] NOT NULL ,
	[too] [smallint] NOT NULL ,
	[paev] [smallint] NOT NULL ,
	[ohtu] [smallint] NOT NULL ,
	[oo] [smallint] NOT NULL ,
	[tahtpaev] [smallint] NOT NULL ,
	[puhapaev] [smallint] NOT NULL ,
	[kuu] [smallint] NOT NULL ,
	[aasta] [smallint] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[palk_taabel2] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentId] [int] NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[too] [smallint] NOT NULL ,
	[paev] [smallint] NOT NULL ,
	[ohtu] [smallint] NOT NULL ,
	[puhkepaev] [smallint] NOT NULL ,
	[kas_puhkus] [smallint] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[pv_kaart] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[vastisikId] [int] NOT NULL ,
	[soetmaks] [money] NOT NULL ,
	[soetkpv] [datetime] NOT NULL ,
	[kulum] [money] NOT NULL ,
	[algkulum] [money] NOT NULL ,
	[gruppId] [int] NOT NULL ,
	[konto] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[tunnus] [smallint] NOT NULL ,
	[mahakantud] [datetime] NULL ,
	[otsus] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[pv_oper] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[nomid] [int] NOT NULL ,
	[doklausid] [int] NOT NULL ,
	[lausendid] [int] NOT NULL ,
	[journalid] [int] NOT NULL ,
	[journal1Id] [int] NOT NULL ,
	[liik] [int] NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[summa] [money] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[raamat] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvId] [int] NOT NULL ,
	[userId] [int] NOT NULL ,
	[aeg] [datetime] NOT NULL ,
	[operatsioon] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[dokument] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[dokid] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[rekv] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[regkood] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[nimetus] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kbmkood] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[aadress] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[haldus] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[tel] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[faks] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[email] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[juht] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[raama] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[recalc] [smallint] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[saldo] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[period] [datetime] NOT NULL ,
	[konto] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[saldo] [money] NOT NULL ,
	[dbkaibed] [money] NOT NULL ,
	[krkaibed] [money] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[saldo1] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[period] [datetime] NOT NULL ,
	[konto] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[asutusid] [int] NOT NULL ,
	[saldo] [money] NOT NULL ,
	[dbkaibed] [money] NOT NULL ,
	[krkaibed] [money] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[saldo2] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[kood1] [int] NOT NULL ,
	[kood2] [int] NOT NULL ,
	[kood3] [int] NOT NULL ,
	[kood4] [int] NOT NULL ,
	[summa] [money] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[sorder1] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[userid] [int] NOT NULL ,
	[journalid] [int] NOT NULL ,
	[kassaid] [int] NOT NULL ,
	[doklausid] [int] NOT NULL ,
	[number] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[asutusid] [int] NOT NULL ,
	[nimi] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[aadress] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[dokument] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[alus] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL ,
	[summa] [money] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[sorder2] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[nomid] [int] NOT NULL ,
	[nimetus] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[summa] [money] NOT NULL ,
	[kood1] [int] NOT NULL ,
	[kood2] [int] NOT NULL ,
	[kood3] [int] NOT NULL ,
	[kood4] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[subkonto] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[kontoid] [int] NOT NULL ,
	[asutusid] [int] NOT NULL ,
	[algsaldo] [money] NOT NULL ,
	[aasta] [float] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tooleping] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[osakondid] [int] NOT NULL ,
	[ametid] [int] NOT NULL ,
	[algab] [datetime] NOT NULL ,
	[lopp] [datetime] NULL ,
	[toopaev] [smallint] NOT NULL ,
	[palk] [money] NOT NULL ,
	[palgamaar] [smallint] NOT NULL ,
	[pohikoht] [smallint] NOT NULL ,
	[koormus] [smallint] NOT NULL ,
	[ametnik] [smallint] NOT NULL ,
	[tasuliik] [smallint] NOT NULL ,
	[pank] [smallint] NOT NULL ,
	[aa] [varchar] (16) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[tuludkulud] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[lausendId] [int] NOT NULL ,
	[konto] [varchar] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[userid] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[kasutaja] [char] (50) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[ametnik] [char] (254) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[parool] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kasutaja_] [int] NOT NULL ,
	[peakasutaja_] [int] NOT NULL ,
	[admin] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[vorder1] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[rekvid] [int] NOT NULL ,
	[userid] [int] NOT NULL ,
	[journalid] [int] NOT NULL ,
	[kassaid] [int] NOT NULL ,
	[doklausid] [int] NOT NULL ,
	[number] [char] (20) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[kpv] [datetime] NOT NULL ,
	[asutusid] [int] NOT NULL ,
	[nimi] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[aadress] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[dokument] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[alus] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[summa] [money] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[vorder2] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[parentid] [int] NOT NULL ,
	[nomid] [int] NOT NULL ,
	[nimetus] [char] (120) COLLATE SQL_Latin1_General_CP1251_CI_AS NOT NULL ,
	[summa] [money] NOT NULL ,
	[kood1] [int] NOT NULL ,
	[kood2] [int] NOT NULL ,
	[kood3] [int] NOT NULL ,
	[kood4] [int] NOT NULL ,
	[muud] [text] COLLATE SQL_Latin1_General_CP1251_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[aa] WITH NOCHECK ADD 
	CONSTRAINT [aa_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[aasta] WITH NOCHECK ADD 
	CONSTRAINT [aasta_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[arv] WITH NOCHECK ADD 
	CONSTRAINT [arv_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[arv1] WITH NOCHECK ADD 
	CONSTRAINT [arv1_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[arvtasu] WITH NOCHECK ADD 
	CONSTRAINT [arvtasu_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[asutus] WITH NOCHECK ADD 
	CONSTRAINT [asutus_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[doklausheader] WITH NOCHECK ADD 
	CONSTRAINT [doklausheader_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[journal1] WITH NOCHECK ADD 
	CONSTRAINT [journal1_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[kontoinf] WITH NOCHECK ADD 
	CONSTRAINT [kontoinf_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[leping1] WITH NOCHECK ADD 
	CONSTRAINT [leping1_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[leping2] WITH NOCHECK ADD 
	CONSTRAINT [leping2_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[library] WITH NOCHECK ADD 
	CONSTRAINT [library_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[nomenklatuur] WITH NOCHECK ADD 
	CONSTRAINT [nomenklatuur_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[rekv] WITH NOCHECK ADD 
	CONSTRAINT [rekv_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[saldo2] WITH NOCHECK ADD 
	CONSTRAINT [saldo2_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[sorder1] WITH NOCHECK ADD 
	CONSTRAINT [sorder1_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[sorder2] WITH NOCHECK ADD 
	CONSTRAINT [sorder2_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[subkonto] WITH NOCHECK ADD 
	CONSTRAINT [subkonto_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[userid] WITH NOCHECK ADD 
	CONSTRAINT [userid_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[vorder1] WITH NOCHECK ADD 
	CONSTRAINT [vorder1_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[vorder2] WITH NOCHECK ADD 
	CONSTRAINT [vorder2_id] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

 CREATE  CLUSTERED  INDEX [parentid] ON [dbo].[doklausend]([parentid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_holidays] ON [dbo].[holidays]([rekvid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [rekvid] ON [dbo].[journal]([rekvid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_ladu_grupp_1] ON [dbo].[ladu_grupp]([nomid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_ladu_jaak] ON [dbo].[ladu_jaak]([nomid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [rekvid] ON [dbo].[lausend]([rekvid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_leping3] ON [dbo].[leping3]([parentid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_palk_config] ON [dbo].[palk_config]([rekvid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_palk_jaak] ON [dbo].[palk_jaak]([lepingId]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_palk_oper_2] ON [dbo].[palk_oper]([LepingId]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_raamat_1] ON [dbo].[raamat]([rekvId]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [rekvid] ON [dbo].[saldo]([rekvid]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [rekvid] ON [dbo].[saldo1]([rekvid]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[aa] WITH NOCHECK ADD 
	CONSTRAINT [DF_aa_arve] DEFAULT (space(20)) FOR [arve],
	CONSTRAINT [DF_aa_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [DF_aa_saldo] DEFAULT (0) FOR [saldo],
	CONSTRAINT [DF_aa_default] DEFAULT (0) FOR [default_],
	CONSTRAINT [DF_aa_kassa] DEFAULT (0) FOR [kassa],
	CONSTRAINT [DF_aa_pank] DEFAULT (0) FOR [pank],
	CONSTRAINT [DF_aa_konto] DEFAULT (space(20)) FOR [konto]
GO

ALTER TABLE [dbo].[aasta] WITH NOCHECK ADD 
	CONSTRAINT [DF_aasta_aasta] DEFAULT (2002) FOR [aasta],
	CONSTRAINT [DF_aasta_KUU] DEFAULT (1) FOR [KUU],
	CONSTRAINT [DF_aasta_kinni] DEFAULT (0) FOR [kinni],
	CONSTRAINT [DF_aasta_default_] DEFAULT (0) FOR [default_]
GO

ALTER TABLE [dbo].[arv] WITH NOCHECK ADD 
	CONSTRAINT [DF_arv_journalid] DEFAULT (0) FOR [journalid],
	CONSTRAINT [DF_arv_doklausid] DEFAULT (0) FOR [doklausid],
	CONSTRAINT [DF_arv_liik] DEFAULT (0) FOR [liik],
	CONSTRAINT [DF_arv_operid] DEFAULT (0) FOR [operid],
	CONSTRAINT [DF_arv_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_arv_asutusid] DEFAULT (0) FOR [asutusid],
	CONSTRAINT [DF_arv_arvid] DEFAULT (0) FOR [arvid],
	CONSTRAINT [DF_arv_lisa] DEFAULT (space(1)) FOR [lisa],
	CONSTRAINT [DF_arv_kbmta] DEFAULT (0) FOR [kbmta],
	CONSTRAINT [DF_arv_kbm] DEFAULT (0) FOR [kbm],
	CONSTRAINT [DF_arv_summa] DEFAULT (0) FOR [summa]
GO

ALTER TABLE [dbo].[arv1] WITH NOCHECK ADD 
	CONSTRAINT [DF_arv1_kogus] DEFAULT (0) FOR [kogus],
	CONSTRAINT [DF_arv1_hind] DEFAULT (0) FOR [hind],
	CONSTRAINT [DF_arv1_soodus] DEFAULT (0) FOR [soodus],
	CONSTRAINT [DF_arv1_kbm] DEFAULT (0) FOR [kbm],
	CONSTRAINT [DF_arv1_maha] DEFAULT (0) FOR [maha],
	CONSTRAINT [DF_arv1_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_arv1_kood1] DEFAULT (0) FOR [kood1],
	CONSTRAINT [DF_arv1_kood2] DEFAULT (0) FOR [kood2],
	CONSTRAINT [DF_arv1_kood3] DEFAULT (0) FOR [kood3],
	CONSTRAINT [DF_arv1_kood4] DEFAULT (0) FOR [kood4]
GO

ALTER TABLE [dbo].[arvtasu] WITH NOCHECK ADD 
	CONSTRAINT [DF_arvtasu_arvid] DEFAULT (0) FOR [arvid],
	CONSTRAINT [DF_arvtasu_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_arvtasu_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_arvtasu_dok] DEFAULT (space(1)) FOR [dok],
	CONSTRAINT [DF_arvtasu_nomid] DEFAULT (0) FOR [nomid],
	CONSTRAINT [DF_arvtasu_pankkassa] DEFAULT (0) FOR [pankkassa],
	CONSTRAINT [DF_arvtasu_journalid] DEFAULT (0) FOR [journalid],
	CONSTRAINT [DF_arvtasu_sorderid] DEFAULT (0) FOR [sorderid],
	CONSTRAINT [DF_arvtasu_doklausId] DEFAULT (0) FOR [doklausId]
GO

ALTER TABLE [dbo].[asutus] WITH NOCHECK ADD 
	CONSTRAINT [DF_asutus_regkood] DEFAULT (space(1)) FOR [regkood],
	CONSTRAINT [DF_asutus_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [DF_asutus_omvorm] DEFAULT (space(1)) FOR [omvorm],
	CONSTRAINT [DF_asutus_aadress] DEFAULT (space(1)) FOR [aadress],
	CONSTRAINT [DF_asutus_kontakt] DEFAULT (space(1)) FOR [kontakt],
	CONSTRAINT [DF_asutus_tel] DEFAULT (space(1)) FOR [tel],
	CONSTRAINT [DF_asutus_faks] DEFAULT (space(1)) FOR [faks],
	CONSTRAINT [DF_asutus_email] DEFAULT (space(1)) FOR [email]
GO

ALTER TABLE [dbo].[doklausend] WITH NOCHECK ADD 
	CONSTRAINT [DF_doklausend_lausendid] DEFAULT (0) FOR [lausendid],
	CONSTRAINT [DF_doklausend_percent] DEFAULT (0) FOR [percent_],
	CONSTRAINT [DF_doklausend_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_doklausend_kood1] DEFAULT (0) FOR [kood1],
	CONSTRAINT [DF_doklausend_kood2] DEFAULT (0) FOR [kood2],
	CONSTRAINT [DF_doklausend_kood3] DEFAULT (0) FOR [kood3],
	CONSTRAINT [DF_doklausend_kood4] DEFAULT (0) FOR [kood4],
	CONSTRAINT [DF_doklausend_kbm] DEFAULT (0) FOR [kbm],
	CONSTRAINT [doklausend_id] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[doklausheader] WITH NOCHECK ADD 
	CONSTRAINT [DF_doklausheader_dok] DEFAULT (space(20)) FOR [dok],
	CONSTRAINT [DF_doklausheader_proc_] DEFAULT (space(20)) FOR [proc_],
	CONSTRAINT [DF_doklausheader_selg] DEFAULT (space(20)) FOR [selg]
GO

ALTER TABLE [dbo].[dokprop] WITH NOCHECK ADD 
	CONSTRAINT [DF_dokprop_proc_] DEFAULT (space(1)) FOR [proc_],
	CONSTRAINT [DF_dokprop_KbmlausendId] DEFAULT (0) FOR [KbmlausendId],
	CONSTRAINT [DF_dokprop_registr] DEFAULT (1) FOR [registr],
	CONSTRAINT [DF_dokprop_vaatalaus] DEFAULT (0) FOR [vaatalaus],
	CONSTRAINT [DF_dokprop_selg] DEFAULT (space(1)) FOR [selg],
	CONSTRAINT [PK_dokprop] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[holidays] WITH NOCHECK ADD 
	CONSTRAINT [DF_holidays_kuu] DEFAULT (1) FOR [kuu],
	CONSTRAINT [DF_holidays_aasta] DEFAULT (1) FOR [paev],
	CONSTRAINT [DF_holidays_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [PK_holidays] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[journal] WITH NOCHECK ADD 
	CONSTRAINT [DF_journal_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_journal_asutusid] DEFAULT (0) FOR [asutusid],
	CONSTRAINT [DF_journal_selg] DEFAULT (space(1)) FOR [selg],
	CONSTRAINT [DF_journal_dok] DEFAULT (space(1)) FOR [dok],
	CONSTRAINT [DF_journal_tunnusid] DEFAULT (0) FOR [tunnusid],
	CONSTRAINT [DF_journal_dokid] DEFAULT (0) FOR [dokid],
	CONSTRAINT [journal_id] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[journal1] WITH NOCHECK ADD 
	CONSTRAINT [DF_journal1_lausendid] DEFAULT (0) FOR [lausendid],
	CONSTRAINT [DF_journal1_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_journal1_dokument] DEFAULT (space(1)) FOR [dokument],
	CONSTRAINT [DF_journal1_kood1] DEFAULT (0) FOR [kood1],
	CONSTRAINT [DF_journal1_kood2] DEFAULT (0) FOR [kood2],
	CONSTRAINT [DF_journal1_kood3] DEFAULT (0) FOR [kood3],
	CONSTRAINT [DF_journal1_kood4] DEFAULT (0) FOR [kood4]
GO

ALTER TABLE [dbo].[journal1TMP] WITH NOCHECK ADD 
	CONSTRAINT [DF_journal1TMP_id] DEFAULT (0) FOR [id],
	CONSTRAINT [DF_journal1TMP_parentid] DEFAULT (0) FOR [parentid],
	CONSTRAINT [DF_journal1TMP_lausendid] DEFAULT (0) FOR [lausendid],
	CONSTRAINT [DF_journal1TMP_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_journal1TMP_kood1] DEFAULT (0) FOR [kood1],
	CONSTRAINT [DF_journal1TMP_kood2] DEFAULT (0) FOR [kood2],
	CONSTRAINT [DF_journal1TMP_kood3] DEFAULT (0) FOR [kood3],
	CONSTRAINT [DF_journal1TMP_kood4] DEFAULT (0) FOR [kood4]
GO

ALTER TABLE [dbo].[journalTMP] WITH NOCHECK ADD 
	CONSTRAINT [DF_journalTMP_id] DEFAULT (0) FOR [id],
	CONSTRAINT [DF_journalTMP_rekvid] DEFAULT (0) FOR [rekvid],
	CONSTRAINT [DF_journalTMP_userid] DEFAULT (0) FOR [userid],
	CONSTRAINT [DF_journalTMP_asutusid] DEFAULT (0) FOR [asutusid],
	CONSTRAINT [DF_journalTMP_tunnusid] DEFAULT (0) FOR [tunnusid],
	CONSTRAINT [DF_journalTMP_dokid] DEFAULT (0) FOR [dokid],
	CONSTRAINT [PK_journalTMP] PRIMARY KEY  NONCLUSTERED 
	(
		[COPYID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[kontoinf] WITH NOCHECK ADD 
	CONSTRAINT [DF_kontoinf_type] DEFAULT (0) FOR [type],
	CONSTRAINT [DF_kontoinf_formula] DEFAULT (0) FOR [formula],
	CONSTRAINT [DF_kontoinf_aasta] DEFAULT (2002) FOR [aasta],
	CONSTRAINT [DF_kontoinf_algsaldo] DEFAULT (0) FOR [algsaldo],
	CONSTRAINT [DF_kontoinf_liik] DEFAULT (1) FOR [liik],
	CONSTRAINT [DF_kontoinf_pohikonto] DEFAULT (space(1)) FOR [pohikonto]
GO

ALTER TABLE [dbo].[ladu_config] WITH NOCHECK ADD 
	CONSTRAINT [DF_ladu_config_liik] DEFAULT (1) FOR [liik]
GO

ALTER TABLE [dbo].[ladu_grupp] WITH NOCHECK ADD 
	CONSTRAINT [DF_ladu_grupp_parentid] DEFAULT (0) FOR [parentid],
	CONSTRAINT [PK_ladu_grupp] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ladu_jaak] WITH NOCHECK ADD 
	CONSTRAINT [DF_ladu_jaak_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_ladu_jaak_hind] DEFAULT (0) FOR [hind],
	CONSTRAINT [DF_ladu_jaak_kogus] DEFAULT (0) FOR [kogus],
	CONSTRAINT [DF_ladu_jaak_maha] DEFAULT (0) FOR [maha],
	CONSTRAINT [DF_ladu_jaak_jaak] DEFAULT (0) FOR [jaak],
	CONSTRAINT [PK_ladu_jaak] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ladu_oper] WITH NOCHECK ADD 
	CONSTRAINT [DF_ladu_oper_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [DF_ladu_oper_liik] DEFAULT (1) FOR [liik],
	CONSTRAINT [DF_ladu_oper_lausendid] DEFAULT (0) FOR [lausendid],
	CONSTRAINT [PK_ladu_oper] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[lausend] WITH NOCHECK ADD 
	CONSTRAINT [DF_lausend_deebet] DEFAULT (space(1)) FOR [deebet],
	CONSTRAINT [DF_lausend_kreedit] DEFAULT (space(1)) FOR [kreedit],
	CONSTRAINT [DF_lausend_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [lausend_id] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[leping1] WITH NOCHECK ADD 
	CONSTRAINT [DF_leping1_doklausid] DEFAULT (0) FOR [doklausid],
	CONSTRAINT [DF_leping1_number] DEFAULT (space(1)) FOR [number],
	CONSTRAINT [DF_leping1_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_leping1_selgitus] DEFAULT (space(1)) FOR [selgitus]
GO

ALTER TABLE [dbo].[leping2] WITH NOCHECK ADD 
	CONSTRAINT [DF_leping2_nomid] DEFAULT (0) FOR [nomid],
	CONSTRAINT [DF_leping2_kogus] DEFAULT (0) FOR [kogus],
	CONSTRAINT [DF_leping2_hind] DEFAULT (0) FOR [hind],
	CONSTRAINT [DF_leping2_soodus] DEFAULT (0) FOR [soodus],
	CONSTRAINT [DF_leping2_status] DEFAULT (1) FOR [status],
	CONSTRAINT [DF_leping2_formula] DEFAULT (space(1)) FOR [formula]
GO

ALTER TABLE [dbo].[leping3] WITH NOCHECK ADD 
	CONSTRAINT [DF_leping3_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_leping3_algkogus] DEFAULT (0) FOR [algkogus],
	CONSTRAINT [DF_leping3_kogus] DEFAULT (0) FOR [loppkogus],
	CONSTRAINT [PK_leping3] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[library] WITH NOCHECK ADD 
	CONSTRAINT [DF_library_kood] DEFAULT (space(1)) FOR [kood],
	CONSTRAINT [DF_library_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [DF_library_library] DEFAULT (space(1)) FOR [library]
GO

ALTER TABLE [dbo].[nomenklatuur] WITH NOCHECK ADD 
	CONSTRAINT [DF_nomenklatuur_doklausid] DEFAULT (0) FOR [doklausid],
	CONSTRAINT [DF_nomenklatuur_dok] DEFAULT (space(20)) FOR [dok],
	CONSTRAINT [DF_nomenklatuur_kood] DEFAULT (space(1)) FOR [kood],
	CONSTRAINT [DF_nomenklatuur_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [DF_nomenklatuur_uhik] DEFAULT (space(1)) FOR [uhik],
	CONSTRAINT [DF_nomenklatuur_hind] DEFAULT (0) FOR [hind]
GO

ALTER TABLE [dbo].[palk_asutus] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_asutus_kogus] DEFAULT (1) FOR [kogus],
	CONSTRAINT [DF_palk_asutus_vaba] DEFAULT (0) FOR [vaba],
	CONSTRAINT [DF_palk_asutus_palgamaar] DEFAULT (0) FOR [palgamaar],
	CONSTRAINT [PK_palk_asutus] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[palk_config] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_config_minpalk] DEFAULT (1850) FOR [minpalk],
	CONSTRAINT [DF_palk_config_tulubaas] DEFAULT (1000) FOR [tulubaas],
	CONSTRAINT [DF_palk_config_round] DEFAULT (0) FOR [round],
	CONSTRAINT [DF_palk_config_jaak] DEFAULT (0) FOR [jaak],
	CONSTRAINT [PK_palk_config] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[palk_jaak] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_jaak_kuu] DEFAULT (1) FOR [kuu],
	CONSTRAINT [DF_palk_jaak_aasta] DEFAULT (2002) FOR [aasta],
	CONSTRAINT [DF_palk_jaak_jaak] DEFAULT (0) FOR [jaak],
	CONSTRAINT [DF_palk_jaak_arv] DEFAULT (0) FOR [arvestatud],
	CONSTRAINT [DF_palk_jaak_kinni] DEFAULT (0) FOR [kinni],
	CONSTRAINT [DF_palk_jaak_tulumaks] DEFAULT (0) FOR [tulumaks],
	CONSTRAINT [DF_palk_jaak_sotsmaks] DEFAULT (0) FOR [sotsmaks],
	CONSTRAINT [DF_palk_jaak_muud] DEFAULT (0) FOR [muud],
	CONSTRAINT [PK_palk_jaak] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[palk_kaart] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_kaart_lepingid] DEFAULT (0) FOR [lepingid],
	CONSTRAINT [DF_palk_kaart_summa] DEFAULT (100) FOR [summa],
	CONSTRAINT [DF_palk_kaart_percent_] DEFAULT (1) FOR [percent_],
	CONSTRAINT [DF_palk_kaart_tulumaks] DEFAULT (1) FOR [tulumaks],
	CONSTRAINT [DF_palk_kaart_tulumaar] DEFAULT (26) FOR [tulumaar],
	CONSTRAINT [DF_palk_kaart_status] DEFAULT (1) FOR [status],
	CONSTRAINT [PK_palk_kaart] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[palk_lib] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_lib_liik] DEFAULT (1) FOR [liik],
	CONSTRAINT [DF_palk_lib_tund] DEFAULT (1) FOR [tund],
	CONSTRAINT [DF_palk_lib_maks] DEFAULT (0) FOR [maks],
	CONSTRAINT [DF_palk_lib_palgafond] DEFAULT (0) FOR [palgafond],
	CONSTRAINT [DF_palk_lib_asutusest] DEFAULT (0) FOR [asutusest],
	CONSTRAINT [DF_palk_lib_lausendId] DEFAULT (0) FOR [lausendId],
	CONSTRAINT [DF_palk_lib_algoritm] DEFAULT (space(1)) FOR [algoritm],
	CONSTRAINT [PK_palk_lib] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[palk_oper] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_oper_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_palk_oper_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_palk_oper_doklausId] DEFAULT (0) FOR [doklausId],
	CONSTRAINT [DF_palk_oper_journalId] DEFAULT (0) FOR [journalId],
	CONSTRAINT [DF_palk_oper_journal1Id] DEFAULT (0) FOR [journal1Id],
	CONSTRAINT [PK_palk_oper] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[palk_taabel1] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_taabel1_kokku] DEFAULT (0) FOR [kokku],
	CONSTRAINT [DF_palk_taabel1_too] DEFAULT (0) FOR [too],
	CONSTRAINT [DF_palk_taabel1_paev] DEFAULT (0) FOR [paev],
	CONSTRAINT [DF_palk_taabel1_ohtu] DEFAULT (0) FOR [ohtu],
	CONSTRAINT [DF_palk_taabel1_oo] DEFAULT (0) FOR [oo],
	CONSTRAINT [DF_palk_taabel1_tahtpaev] DEFAULT (0) FOR [tahtpaev],
	CONSTRAINT [DF_palk_taabel1_puhapaev] DEFAULT (0) FOR [puhapaev],
	CONSTRAINT [DF_palk_taabel1_kuu] DEFAULT (0) FOR [kuu],
	CONSTRAINT [DF_palk_taabel1_aasta] DEFAULT (0) FOR [aasta],
	CONSTRAINT [PK_palk_taabel1] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[palk_taabel2] WITH NOCHECK ADD 
	CONSTRAINT [DF_palk_taabel2_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_palk_taabel2_too] DEFAULT (0) FOR [too],
	CONSTRAINT [DF_palk_taabel2_paev] DEFAULT (0) FOR [paev],
	CONSTRAINT [DF_palk_taabel2_ohtu] DEFAULT (0) FOR [ohtu],
	CONSTRAINT [DF_palk_taabel2_puhkepaev] DEFAULT (0) FOR [puhkepaev],
	CONSTRAINT [DF_palk_taabel2_kas_puhkus] DEFAULT (0) FOR [kas_puhkus],
	CONSTRAINT [PK_palk_taabel2] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[raamat] WITH NOCHECK ADD 
	CONSTRAINT [DF_raamat_aeg] DEFAULT (getdate()) FOR [aeg],
	CONSTRAINT [DF_raamat_operatsioon] DEFAULT (space(1)) FOR [operatsioon],
	CONSTRAINT [DF_raamat_dokument] DEFAULT (space(1)) FOR [dokument],
	CONSTRAINT [DF_raamat_dokid] DEFAULT (0) FOR [dokid],
	CONSTRAINT [PK_raamat] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[rekv] WITH NOCHECK ADD 
	CONSTRAINT [DF_rekv_regkood] DEFAULT (space(20)) FOR [regkood],
	CONSTRAINT [DF_rekv_nimetus] DEFAULT (space(20)) FOR [nimetus],
	CONSTRAINT [DF_rekv_kbmkood] DEFAULT (space(20)) FOR [kbmkood],
	CONSTRAINT [DF_rekv_aadress] DEFAULT (space(20)) FOR [aadress],
	CONSTRAINT [DF_rekv_haldus] DEFAULT (space(20)) FOR [haldus],
	CONSTRAINT [DF_rekv_tel] DEFAULT (space(20)) FOR [tel],
	CONSTRAINT [DF_rekv_faks] DEFAULT (space(20)) FOR [faks],
	CONSTRAINT [DF_rekv_email] DEFAULT (space(20)) FOR [email],
	CONSTRAINT [DF_rekv_juht] DEFAULT (space(20)) FOR [juht],
	CONSTRAINT [DF_rekv_raama] DEFAULT (space(20)) FOR [raama],
	CONSTRAINT [DF_rekv_recalc] DEFAULT (0) FOR [recalc]
GO

ALTER TABLE [dbo].[saldo] WITH NOCHECK ADD 
	CONSTRAINT [DF_saldo_saldo] DEFAULT (0) FOR [saldo],
	CONSTRAINT [DF_saldo_dbkaibed] DEFAULT (0) FOR [dbkaibed],
	CONSTRAINT [DF_saldo_krkaibed] DEFAULT (0) FOR [krkaibed],
	CONSTRAINT [saldo_id] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[saldo1] WITH NOCHECK ADD 
	CONSTRAINT [DF_saldo1_saldo] DEFAULT (0) FOR [saldo],
	CONSTRAINT [DF_saldo1_dbkaibed] DEFAULT (0) FOR [dbkaibed],
	CONSTRAINT [DF_saldo1_krkaibed] DEFAULT (0) FOR [krkaibed],
	CONSTRAINT [saldo1_id] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[saldo2] WITH NOCHECK ADD 
	CONSTRAINT [DF_saldo2_kood1] DEFAULT (0) FOR [kood1],
	CONSTRAINT [DF_saldo2_kood2] DEFAULT (0) FOR [kood2],
	CONSTRAINT [DF_saldo2_kood3] DEFAULT (0) FOR [kood3],
	CONSTRAINT [DF_saldo2_kood4] DEFAULT (0) FOR [kood4],
	CONSTRAINT [DF_saldo2_summa] DEFAULT (0) FOR [summa]
GO

ALTER TABLE [dbo].[sorder1] WITH NOCHECK ADD 
	CONSTRAINT [DF_sorder1_journalid] DEFAULT (0) FOR [journalid],
	CONSTRAINT [DF_sorder1_doklausid] DEFAULT (0) FOR [doklausid],
	CONSTRAINT [DF_sorder1_summa] DEFAULT (0) FOR [summa]
GO

ALTER TABLE [dbo].[sorder2] WITH NOCHECK ADD 
	CONSTRAINT [DF_sorder2_nomid] DEFAULT (0) FOR [nomid],
	CONSTRAINT [DF_sorder2_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_sorder2_kood1] DEFAULT (0) FOR [kood1],
	CONSTRAINT [DF_sorder2_kood2] DEFAULT (0) FOR [kood2],
	CONSTRAINT [DF_sorder2_kood3] DEFAULT (0) FOR [kood3],
	CONSTRAINT [DF_sorder2_kood4] DEFAULT (0) FOR [kood4]
GO

ALTER TABLE [dbo].[subkonto] WITH NOCHECK ADD 
	CONSTRAINT [DF_subkonto_kontoid] DEFAULT (0) FOR [kontoid],
	CONSTRAINT [DF_subkonto_asutusid] DEFAULT (0) FOR [asutusid],
	CONSTRAINT [DF_subkonto_algsaldo] DEFAULT (0) FOR [algsaldo],
	CONSTRAINT [DF_subkonto_aasta] DEFAULT (0) FOR [aasta]
GO

ALTER TABLE [dbo].[tooleping] WITH NOCHECK ADD 
	CONSTRAINT [DF_tooleping_osakondid] DEFAULT (0) FOR [osakondid],
	CONSTRAINT [DF_tooleping_ametid] DEFAULT (0) FOR [ametid],
	CONSTRAINT [DF_tooleping_algab] DEFAULT (getdate()) FOR [algab],
	CONSTRAINT [DF_tooleping_toopaev] DEFAULT (8) FOR [toopaev],
	CONSTRAINT [DF_tooleping_palk] DEFAULT (0) FOR [palk],
	CONSTRAINT [DF_tooleping_palgamaar] DEFAULT (0) FOR [palgamaar],
	CONSTRAINT [DF_tooleping_pohikoht] DEFAULT (1) FOR [pohikoht],
	CONSTRAINT [DF_tooleping_koormus] DEFAULT (100) FOR [koormus],
	CONSTRAINT [DF_tooleping_ametnik] DEFAULT (0) FOR [ametnik],
	CONSTRAINT [DF_tooleping_tasuliik] DEFAULT (1) FOR [tasuliik],
	CONSTRAINT [DF_tooleping_pank] DEFAULT (401) FOR [pank],
	CONSTRAINT [DF_tooleping_aa] DEFAULT (space(1)) FOR [aa],
	CONSTRAINT [PK_tooleping] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tuludkulud] WITH NOCHECK ADD 
	CONSTRAINT [PK_tuludkulud] PRIMARY KEY  NONCLUSTERED 
	(
		[id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[userid] WITH NOCHECK ADD 
	CONSTRAINT [DF_userid_kasutaja_] DEFAULT (1) FOR [kasutaja_],
	CONSTRAINT [DF_userid_peakasutaja_] DEFAULT (0) FOR [peakasutaja_],
	CONSTRAINT [DF_userid_admin] DEFAULT (0) FOR [admin]
GO

ALTER TABLE [dbo].[vorder1] WITH NOCHECK ADD 
	CONSTRAINT [DF_vorder1_journalid] DEFAULT (0) FOR [journalid],
	CONSTRAINT [DF_vorder1_kassaid] DEFAULT (0) FOR [kassaid],
	CONSTRAINT [DF_vorder1_doklausid] DEFAULT (0) FOR [doklausid],
	CONSTRAINT [DF_vorder1_number] DEFAULT (space(1)) FOR [number],
	CONSTRAINT [DF_vorder1_kpv] DEFAULT (getdate()) FOR [kpv],
	CONSTRAINT [DF_vorder1_asutusid] DEFAULT (0) FOR [asutusid],
	CONSTRAINT [DF_vorder1_nimi] DEFAULT (space(1)) FOR [nimi],
	CONSTRAINT [DF_vorder1_aadress] DEFAULT (space(1)) FOR [aadress],
	CONSTRAINT [DF_vorder1_dokument] DEFAULT (space(1)) FOR [dokument],
	CONSTRAINT [DF_vorder1_alus] DEFAULT (space(1)) FOR [alus],
	CONSTRAINT [DF_vorder1_summa] DEFAULT (0) FOR [summa]
GO

ALTER TABLE [dbo].[vorder2] WITH NOCHECK ADD 
	CONSTRAINT [DF_vorder2_nomid] DEFAULT (0) FOR [nomid],
	CONSTRAINT [DF_vorder2_nimetus] DEFAULT (space(1)) FOR [nimetus],
	CONSTRAINT [DF_vorder2_summa] DEFAULT (0) FOR [summa],
	CONSTRAINT [DF_vorder2_kood1] DEFAULT (0) FOR [kood1],
	CONSTRAINT [DF_vorder2_kood2] DEFAULT (0) FOR [kood2],
	CONSTRAINT [DF_vorder2_kood3] DEFAULT (0) FOR [kood3],
	CONSTRAINT [DF_vorder2_kood4] DEFAULT (0) FOR [kood4]
GO

 CREATE  INDEX [parentid] ON [dbo].[aa]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [pank] ON [dbo].[aa]([pank]) ON [PRIMARY]
GO

 CREATE  INDEX [konto] ON [dbo].[aa]([konto]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[aasta]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [arvid] ON [dbo].[arv]([arvid]) ON [PRIMARY]
GO

 CREATE  INDEX [asutusid] ON [dbo].[arv]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[arv]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [userid] ON [dbo].[arv]([userid]) ON [PRIMARY]
GO

 CREATE  INDEX [journalid] ON [dbo].[arv]([journalid]) ON [PRIMARY]
GO

 CREATE  INDEX [nomid] ON [dbo].[arv1]([nomid]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[arv1]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [nomid] ON [dbo].[arvtasu]([nomid]) ON [PRIMARY]
GO

 CREATE  INDEX [kpv] ON [dbo].[arvtasu]([kpv]) ON [PRIMARY]
GO

 CREATE  INDEX [arvid] ON [dbo].[arvtasu]([arvid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[arvtasu]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [sorderid] ON [dbo].[arvtasu]([sorderid]) ON [PRIMARY]
GO

 CREATE  INDEX [journalid] ON [dbo].[arvtasu]([journalid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[asutus]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[doklausheader]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [asutusid] ON [dbo].[journal]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [userid] ON [dbo].[journal]([userid]) ON [PRIMARY]
GO

 CREATE  INDEX [tunnusid] ON [dbo].[journal]([tunnusid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_journal] ON [dbo].[journal]([kpv]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[journal1]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [lausendid] ON [dbo].[journal1]([lausendid]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[kontoinf]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_ladu_grupp] ON [dbo].[ladu_grupp]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_ladu_jaak_1] ON [dbo].[ladu_jaak]([kpv]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_ladu_jaak_2] ON [dbo].[ladu_jaak]([dokItemId]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_ladu_jaak_3] ON [dbo].[ladu_jaak]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_ladu_oper] ON [dbo].[ladu_oper]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_ladu_oper_1] ON [dbo].[ladu_oper]([lausendid]) ON [PRIMARY]
GO

 CREATE  INDEX [asutusid] ON [dbo].[leping1]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[leping1]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [nomid] ON [dbo].[leping2]([nomid]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[leping2]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[library]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[nomenklatuur]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [doklausid] ON [dbo].[nomenklatuur]([doklausid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_palk_oper] ON [dbo].[palk_oper]([rekvId]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_palk_oper_1] ON [dbo].[palk_oper]([libId]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_palk_taabel1] ON [dbo].[palk_taabel1]([toolepingId]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_palk_taabel2] ON [dbo].[palk_taabel2]([parentId]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_palk_taabel2_1] ON [dbo].[palk_taabel2]([kpv]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_raamat] ON [dbo].[raamat]([rekvId]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[rekv]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [konto] ON [dbo].[saldo]([konto]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_saldo] ON [dbo].[saldo]([period]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_saldo_1] ON [dbo].[saldo]([konto]) ON [PRIMARY]
GO

 CREATE  INDEX [asutusid] ON [dbo].[saldo1]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_saldo1] ON [dbo].[saldo1]([period]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_saldo1_1] ON [dbo].[saldo1]([konto]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_saldo1_2] ON [dbo].[saldo1]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [kood4] ON [dbo].[saldo2]([kood4]) ON [PRIMARY]
GO

 CREATE  INDEX [kood2] ON [dbo].[saldo2]([kood2]) ON [PRIMARY]
GO

 CREATE  INDEX [kood1] ON [dbo].[saldo2]([kood1]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[saldo2]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [asutusid] ON [dbo].[sorder1]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [userid] ON [dbo].[sorder1]([userid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[sorder1]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [kassaid] ON [dbo].[sorder1]([kassaid]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[sorder2]([parentid]) ON [PRIMARY]
GO

 CREATE  INDEX [kontoid] ON [dbo].[subkonto]([kontoid]) ON [PRIMARY]
GO

 CREATE  INDEX [asutusid] ON [dbo].[subkonto]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_tuludkulud] ON [dbo].[tuludkulud]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [IX_tuludkulud_1] ON [dbo].[tuludkulud]([lausendId]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[userid]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [kassaid] ON [dbo].[vorder1]([kassaid]) ON [PRIMARY]
GO

 CREATE  INDEX [userid] ON [dbo].[vorder1]([userid]) ON [PRIMARY]
GO

 CREATE  INDEX [rekvid] ON [dbo].[vorder1]([rekvid]) ON [PRIMARY]
GO

 CREATE  INDEX [asutusid] ON [dbo].[vorder1]([asutusid]) ON [PRIMARY]
GO

 CREATE  INDEX [parentid] ON [dbo].[vorder2]([parentid]) ON [PRIMARY]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[aa]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[aa]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[aasta]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[aasta]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[arv]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[arv]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[arv1]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[arv1]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[arvtasu]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[arvtasu]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[asutus]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[asutus]  TO [dbkasutaja]
GO

GRANT  SELECT  ON [dbo].[dbase]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[dbase]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[doklausend]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[doklausend]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[doklausheader]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[doklausheader]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[dokprop]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[dokprop]  TO [dbadmin]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[dokprop]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[dokprop]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[holidays]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[holidays]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journal]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journal]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journal1]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journal1]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journal1TMP]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journal1TMP]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journalTMP]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[journalTMP]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[kontoinf]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[kontoinf]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_config]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[ladu_config]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_grupp]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_grupp]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_jaak]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_jaak]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_minkogus]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[ladu_minkogus]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_oper]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[ladu_oper]  TO [dbkasutaja]
GO

GRANT  SELECT  ON [dbo].[ladu_ulehind]  TO [dbadmin]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_ulehind]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ladu_ulehind]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[lausdok]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[lausdok]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[lausend]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[lausend]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[leping1]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[leping1]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[leping2]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[leping2]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[leping3]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[leping3]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[library]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[library]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[nomenklatuur]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[nomenklatuur]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_asutus]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_asutus]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_config]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[palk_config]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_jaak]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_jaak]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_kaart]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_kaart]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_lib]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_lib]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_oper]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_oper]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_taabel1]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_taabel1]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_taabel2]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[palk_taabel2]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[pv_kaart]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[pv_kaart]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[pv_oper]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[pv_oper]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[raamat]  TO [public]
GO

DENY  DELETE  ON [dbo].[raamat]  TO [public] CASCADE 
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[raamat]  TO [dbadmin]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[raamat]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[raamat]  TO [dbkasutaja]
GO

DENY  DELETE  ON [dbo].[raamat]  TO [dbkasutaja] CASCADE 
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[rekv]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[rekv]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[saldo]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[saldo]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[saldo1]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[saldo1]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[saldo2]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[saldo2]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[sorder1]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[sorder1]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[sorder2]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[sorder2]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[subkonto]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[subkonto]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tooleping]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tooleping]  TO [dbkasutaja]
GO

GRANT  REFERENCES ,  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tuludkulud]  TO [dbadmin]
GO

GRANT  REFERENCES ,  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tuludkulud]  TO [dbpeakasutaja]
GO

GRANT  REFERENCES ,  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tuludkulud]  TO [dbkasutaja]
GO

GRANT  SELECT  ON [dbo].[userid]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[userid]  TO [dbadmin]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[userid]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT  ON [dbo].[userid]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[vorder1]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[vorder1]  TO [dbkasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[vorder2]  TO [dbpeakasutaja]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[vorder2]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigI_aa ON dbo.aa FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.parentid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigU_aa ON dbo.aa FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(parentid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.parentid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'vorder1' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, vorder1 WHERE (deleted.id = vorder1.kassaid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''vorder1''.'            SELECT @status='Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigD_aa ON dbo.aa FOR DELETE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT DELETES IF DEPENDENT RECORDS IN 'vorder1' */IF (SELECT COUNT(*) FROM deleted, vorder1 WHERE (deleted.id = vorder1.kassaid)) > 0    BEGIN    RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''vorder1''.'    SELECT @status='Failed'    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid 
ON aasta 
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_arv ON dbo.arv FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* PREVENT INSERTS IF NO MATCHING KEY IN 'asutus' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION
else
select id from inserted



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_arv ON dbo.arv FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF NO MATCHING KEY IN 'asutus' */IF UPDATE(asutusid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_trig_i_arv1 
ON arv1
FOR INSERT 
AS
declare @operId		int,
	@liik		int,
	@parent	int,
	@arv1id	int,
	@LifoFifo 	int,
	@rekv		int,
	@nomId	int,
	@kogus	money,
	@dokItemId	int
select @arv1id = i.id, @parent = i.parentId, @nomid = i.nomId, @kogus = i.kogus from inserted i inner join ladu_grupp on ladu_grupp.nomId = i.nomId 
set @parent = isnull(@parent,0)
if @parent > 0
begin
select @operid = operId, @liik = liik, @rekv = rekvid from arv where id = @parent 
if @operId > 0  and @liik = 1
	begin
	/* vara sisetulik*/
		insert ladu_jaak 
			select arv.rekvid, arv1.id as dokitemid, nomid, userid, kpv, hind, kogus, 0 as maha, arv1.kogus as jaak 
				from arv inner join arv1 on arv.id = arv1.parentid
				where arv1.id = @arv1id 
	end	
if @operId > 0  and @liik = 0
	begin
	/*vara valjaminek */
	begin tran
	declare @id		int, 
		@jaak		money,
		@maha		money,	
		@kpv		datetime
	select @LifoFifo = liik from ladu_config where rekvid = @rekv 
	set @LifoFifo = isnull(@LifoFifo,1)
	if @LifoFifo = 1
		begin
		/* Lifo */
			declare cur_ladujaak cursor
				for select   id, jaak, maha, kpv, dokItemId   
				from ladu_jaak
				where rekvid = @rekv
				and jaak > 0
				and nomid = @nomId
				order by kpv 
		end
	else
		/* FiFo*/
		begin
			declare cur_ladujaak cursor
				for select   id, jaak, maha, kpv, dokItemId   
				from ladu_jaak
				where rekvid = @rekv
				and jaak > 0
				and nomid = @nomId
				order by kpv desc
		end
	open cur_ladujaak
	fetch  cur_ladujaak into @id, @jaak, @maha, @kpv, @dokItemId
	while @@fetch_status = 0  
	begin
		if @Jaak >= @kogus and @Kogus > 0
			begin
				
				update arv1 set maha = 1 where id = @dokItemId and maha = 0
				update ladu_jaak set jaak = @jaak - @kogus, maha = @maha + @kogus where id = @id
				set @kogus = 0
				if (@maha + @kogus) > @jaak
					raiserror (' ei saa mahakandma nii palja kaupa', 16, 10)
			end	
		if @Jaak < @kogus and @kogus >= 0	
			begin
				update arv1 set maha = 1 where id = @dokItemId and maha = 0
				update ladu_jaak set jaak = 0, maha = maha + (@kogus - @jaak) where id = @id
				set @kogus = @kogus - @jaak				
			end
		delete from ladu_jaak where jaak = 0
		fetch  cur_ladujaak into @id, @jaak, @maha, @kpv, @dokItemId
	end
	close cur_ladujaak
	deallocate cur_ladujaak
	if @kogus > 0
		begin
			rollback tran
			raiserror ('Ladus ei ole kaupa', 16, 10)
		end
	else
		commit tran
end
end
select id from inserted



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_trigD_arv1 
ON arv1
FOR DELETE 
AS
declare @maha		int,
	@id		int,
	@liik		int,
	@operid	int
select @maha = maha from deleted
select @maha as maha
if @maha = 1	
	begin
		print 'maha:'+str (@maha)
		rollback tran
		raiserror (' ei saa parandada makantud dokument ', 16, 10)
	end
else
	begin
		select @id = parentid from deleted 
		select @liik = arv.liik, @operid = operid from arv where id = @id
		select @liik as liik, @operid as operid, @id as id
		if @operId > 0	and @liik = 1
			begin
				print 'deleting'
				/* sistulik*/
				delete from ladu_jaak where dokitemid in (select id from deleted)
			end
		if @operId > 0	and @liik = 0
			begin
				/* valjaminek*/
				print 'rollback'	
				rollback tran
				raiserror (' ei saa parandada makantud dokument ', 16, 10)
			end
	end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_trigU_arv1
ON arv1
FOR  UPDATE
AS
declare @maha		int,
	@kpv		datetime,
	@summa	money,
	@kogus	money,
	@nomid		int,
	@hind		money,
	@kpvi		datetime,
	@summai	money,
	@kogusi	INT

declare 	@hindi		money,	
	@id		int,
	@NomIdi	int
select @maha = maha from deleted
if @maha = 1
	begin
		select @id = deleted.parentid from deleted
		select @summa = d.summa, @hind = d.hind, @kogus = d.kogus, @nomid = d.nomid from arv, deleted d where arv.id = @id
 		select  @summai = i.summa, @hindi = i.hind, @kogusi = i.kogus, @nomidi = i.nomid from inserted i 
		if @summa <> @summai or @kogus <> @kogusi or @nomid <> @nomidi
			begin
				raiserror (' ei saa parandada makantud dokument ', 16, 10)
			end		
	end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_getid_arvtasu 
ON dbo.arvtasu
FOR INSERT 
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_asutus ON dbo.asutus FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_asutus ON dbo.asutus FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'journal' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, journal WHERE (deleted.id = journal.asutusid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''journal''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'arv' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, arv WHERE (deleted.id = arv.asutusid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''arv''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'subkonto' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, subkonto WHERE (deleted.id = subkonto.asutusid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''subkonto''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'saldo1' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, saldo1 WHERE (deleted.id = saldo1.asutusid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''saldo1''.'            SELECT @status='Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigD_asutus ON dbo.asutus FOR DELETE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT DELETES IF DEPENDENT RECORDS IN 'journal' */IF (SELECT COUNT(*) FROM deleted, journal WHERE (deleted.id = journal.asutusid)) > 0    BEGIN    RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''journal''.'    SELECT @status='Failed'    END/* PREVENT DELETES IF DEPENDENT RECORDS IN 'arv' */IF (SELECT COUNT(*) FROM deleted, arv WHERE (deleted.id = arv.asutusid)) > 0    BEGIN    RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''arv''.'    SELECT @status='Failed'    END/* PREVENT DELETES IF DEPENDENT RECORDS IN 'sorder1' */IF (SELECT COUNT(*) FROM deleted, sorder1 WHERE (deleted.id = sorder1.asutusid)) > 0    BEGIN    RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''sorder1''.'    SELECT @status='Failed'    END/* PREVENT DELETES IF DEPENDENT RECORDS IN 'vorder1' */IF (SELECT COUNT(*) FROM deleted, vorder1 WHERE (deleted.id = vorder1.asutusid)) > 0    BEGIN    RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''vorder1''.'    SELECT @status='Failed'    END/* CASCADE DELETES TO 'subkonto' */DELETE subkonto FROM deleted, subkonto WHERE deleted.id = subkonto.asutusid/* CASCADE DELETES TO 'saldo1' */DELETE saldo1 FROM deleted, saldo1 WHERE deleted.id = saldo1.asutusid/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_GetId_doklausend 
ON doklausend 
FOR INSERT 
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getId_doklausHeader
ON dokLausHeader
FOR INSERT
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_dokprop 
ON dokprop 
FOR INSERT 
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_holidays 
ON holidays
FOR INSERT 
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_journal ON dbo.journal FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'asutus' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'            SELECT @status='Failed'        END    END/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* PREVENT INSERTS IF NO MATCHING KEY IN 'userid' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM userid, inserted WHERE (userid.id = inserted.userid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''userid''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION
select id from inserted 


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_journal ON dbo.journal FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'asutus' */IF UPDATE(asutusid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF NO MATCHING KEY IN 'userid' */IF UPDATE(userid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM userid, inserted WHERE (userid.id = inserted.userid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''userid''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigD_journal ON dbo.journal FOR DELETE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* CASCADE DELETES TO 'journal1' */DELETE journal1 FROM deleted, journal1 WHERE deleted.id = journal1.parentid/* CASCADE DELETES TO 'arvtasu' */DELETE arvtasu FROM deleted, arvtasu WHERE deleted.id = arvtasu.journalid/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER check_kinnitamine 
ON journal
FOR INSERT,UPDATE 
AS
declare @nKuu		int,
	@Rekv		int,
	@nAasta	int,
	@nKinni	int

select @nKuu = datepart   ( month, kpv ), @nAasta = datepart ( year, kpv), @rekv = rekvid  from inserted 
select @nKinni = kinni from aasta where kuu = @nKuu and aasta = @nAasta and rekvid = @rekv 
if @nKinni = 1
	begin
		rollback tran
		raiserror ('Period on kinnitatud', 16, 10)
	end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER check_kinnitamine_for_delete
ON journal
FOR  DELETE 
AS
declare @nKuu		int,
	@Rekv		int,
	@nAasta	int,
	@nKinni	int

select @nKuu = datepart   ( month, kpv ), @nAasta = datepart ( year, kpv), @rekv = rekvid  from deleted
select @nKinni = kinni from aasta where kuu = @nKuu and aasta = @nAasta and rekvid = @rekv 
if @nKinni = 1
	begin
		rollback tran
		raiserror ('Period on kinnitatud', 16, 10)
	end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_checksubkonto_journal1 
ON journal1
FOR UPDATE
AS
declare @deebet	varchar (20),
	@kreedit 	varchar (20),
	@subkontoid	int,
	@asutusid	int,
	@aasta		int,
	@parentid	int,
	@kontoid	int,
	@rekvid	int

select @asutusid = asutusid, @aasta = datepart (year, journal.kpv), @rekvid = journal.rekvid from journal, inserted i where journal.id = i.parentid
set @asutusid = isnull(@asutusid,0)
if @asutusId > 0
	begin
		select @deebet = lausend.deebet, @kreedit = lausend.kreedit, @parentid = i.parentid from lausend inner join  inserted i on i.lausendid = lausend.id
		select @kontoid = library.id from library where kood = @deebet and rekvid = @rekvid and library.library = 'KONTOD'
		select @subkontoid = subkonto.id from subkonto  WHERE kontoid = @kontoid and asutusId = @asutusId 
		set @subkontoid = isnull(@subkontoid,0)
		if @subkontoid = 0
			insert into subkonto (algsaldo, aasta, kontoid, asutusid) values (0, @aasta, @kontoid, @asutusid)
		select @kontoid = library.id from library where kood = @kreedit and rekvid = @rekvid and library = 'KONTOD'
		select @subkontoid = subkonto.id from subkonto  where kontoid = @kontoid and asutusId = @asutusId 
		set @subkontoid = isnull(@subkontoid,0)
		if @subkontoid = 0
			insert into subkonto (algsaldo, aasta, kontoid, asutusid) values (0, @aasta, @kontoid, @asutusid)	
	end
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_getid_journal1 
ON journal1
FOR INSERT
AS
declare @deebet	varchar (20),
	@kreedit 	varchar (20),
	@subkontoid	int,
	@asutusid	int,
	@aasta		int,
	@parentid	int,
	@kontoid	int,
	@rekvid	int

select @asutusid = asutusid, @aasta = datepart (year, journal.kpv), @rekvid = journal.rekvid from journal, inserted i where journal.id = i.parentid
set @asutusid = isnull(@asutusid,0)
if @asutusId > 0
	begin
		select @deebet = lausend.deebet, @kreedit = lausend.kreedit, @parentid = i.parentid from lausend inner join  inserted i on i.lausendid = lausend.id
		select @kontoid = library.id from library where kood = @deebet and rekvid = @rekvid and library.library = 'KONTOD'
		select @subkontoid = subkonto.id from subkonto  WHERE kontoid = @kontoid and asutusId = @asutusId 
		set @subkontoid = isnull(@subkontoid,0)
		if @subkontoid = 0
			insert into subkonto (algsaldo, aasta, kontoid, asutusid) values (0, @aasta, @kontoid, @asutusid)
		select @kontoid = library.id from library where kood = @kreedit and rekvid = @rekvid and library = 'KONTOD'
		select @subkontoid = subkonto.id from subkonto  where kontoid = @kontoid and asutusId = @asutusId 
		set @subkontoid = isnull(@subkontoid,0)
		if @subkontoid = 0
			insert into subkonto (algsaldo, aasta, kontoid, asutusid) values (0, @aasta, @kontoid, @asutusid)	
	end
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_kontoinf ON dbo.kontoinf FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'library' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM library, inserted WHERE (library.id = inserted.parentid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''library''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_kontoinf ON dbo.kontoinf FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'library' */IF UPDATE(parentid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM library, inserted WHERE (library.id = inserted.parentid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''library''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER trigD_kontoinf 
ON kontoinf
FOR DELETE 
AS
declare @kood	varchar(20)
select @kood = kood from library, deleted  where library.id = deleted.parentid
select top 1 id from lausend where deebet = @kood or kreedit = @kood
if @@rowcount > 0
	    RAISERROR ('Ei saa kustuta konto', 16, 1)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_lausdok 
ON lausdok
FOR INSERT 
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER CHEK_FOR_JOURNAL1  
ON LAUSEND
FOR DELETE 
AS
DECLARE @ID	INT
select top 1 @id = JOURNAL1.id  from journal1, deleted  where lausendid = deleted.id
set @id = isnull(@id,0)
if @id > 0
	raiserror ('Ei saa kusttuta sest lausend kasutatab dokumendis',16,10)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER check_for_update 
ON lausend 
FOR UPDATE
AS
declare @id	int,
	@deebet_vana	varchar(20),
	@kreedit_vana	varchar(20),
	@deebet_uus	varchar(20),
	@kreedit_uus	varchar(20)

select top 1 @id =journal1. id from journal1, deleted where lausendid = deleted.id
set @id = isnull(@id,0)
if @id > 0
	begin
		select @deebet_vana = deebet, @kreedit_vana = kreedit  from deleted
		select @deebet_uus = deebet, @kreedit_uus = kreedit  from inserted
		if @deebet_vana <> @deebet_uus or @kreedit_vana <> @kreedit_uus
			raiserror ('Ei saa parandada lausend',16,10)				
	end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_lausend
ON lausend
FOR INSERT
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_leping1 
ON leping1
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_getid_leping2 
ON dbo.leping2
FOR INSERT 
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_library ON dbo.library FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */
declare		@LIBRARY  	varchar(20),	
		@kood		varchar(20),
		@count		int,
		@rekvid	int,
		@period	datetime,
		@kuu		int,
		@cKuu		varchar(2)SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'	ROLLBACK TRANSACTION
else
	begin
		select @library = library, @kood = kood, @rekvid = rekvid  from inserted 
		if @library = 'KONTOD'
			begin
				select @count = count (id) from saldo where   rekvid = @rekvid and konto = @kood 
				set @count = isnull(@count,0)
				if @count < 1
					begin
						set @kuu = 1
						while @kuu < 13
							begin
								if @kuu < 10
									set @cKuu = '0'+cast(@kuu as varchar(2))
								set @period =  cast(datepart (year,getdate()) as char(4))+@cKuu+'01'
								insert into saldo (rekvid, konto, period) values (@rekvid, @kood, @period)
								set @kuu = @kuu + 1
							end
					end
			end	
		select id from inserted
	end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_library ON dbo.library FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'kontoinf' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, kontoinf WHERE (deleted.id = kontoinf.parentid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''kontoinf''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'subkonto' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, subkonto WHERE (deleted.id = subkonto.kontoid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''subkonto''.'            SELECT @status='Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigD_library ON dbo.library FOR DELETE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* CASCADE DELETES TO 'kontoinf' */DELETE kontoinf FROM deleted, kontoinf WHERE deleted.id = kontoinf.parentid/* CASCADE DELETES TO 'subkonto' */DELETE subkonto FROM deleted, subkonto WHERE deleted.id = subkonto.kontoid/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_nomenklatuur ON dbo.nomenklatuur FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_nomenklatuur ON dbo.nomenklatuur FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_nomenklatuur 
ON nomenklatuur
FOR INSERT
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_palk_asutus
ON palk_asutus
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_check_newid 
ON palk_config
FOR INSERT
AS
select * from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_palk_config
ON palk_config
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getId_palk_jaak
ON palk_jaak
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_palk_kaart
ON palk_kaart
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_palk_lib
ON palk_lib
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER spD_recalk_jaak 
ON dbo.palk_oper
FOR DELETE
AS
declare @kpv1	datetime,
	@kpv2	datetime,
	@rekv	int,
	@lepId	int

select @kpv1 = '01.'+cast (datepart (month, i.kpv) as char(2)) +'.'+
	cast (datepart ( year, i.kpv) as char(4)),
	@kpv2 = dateadd (month,1, @kpv1 ) - 1, @rekv = i.rekvId, @lepId = i.lepingid from deleted i

exec sp_update_palk_jaak @KPV1, @kpv2, @rekv, @lepId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER spI_recalk_jaak 
ON dbo.palk_oper
FOR INSERT, UPDATE
AS
declare @kpv1	datetime,
	@kpv2	datetime,
	@rekv	int,
	@lepId	int,
	@id	int
select @id = id from inserted

select @kpv1 = '01.'+cast (datepart (month, i.kpv) as char(2)) +'.'+
	cast (datepart ( year, i.kpv) as char(4)),
	@kpv2 = dateadd (month,1, @kpv1 ) - 1, @rekv = i.rekvId, @lepId = i.lepingid from inserted i
exec sp_update_palk_jaak @KPV1, @kpv2, @rekv, @lepId
select @id as id 



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_getid_palk_taabel1
ON dbo.palk_taabel1
FOR INSERT
AS
select id from inserted

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_palk_taabel2
ON palk_taabel2
FOR INSERT
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_pvkaart
ON pv_kaart
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_pv_oper
ON pv_oper
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_rekv 
ON rekv 
FOR INSERT
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigU_rekv ON dbo.rekv FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'arv' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, arv WHERE (deleted.id = arv.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''arv''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'nomenklatuur' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, nomenklatuur WHERE (deleted.id = nomenklatuur.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''nomenklatuur''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'journal' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, journal WHERE (deleted.id = journal.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''journal''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'asutus' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, asutus WHERE (deleted.id = asutus.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''asutus''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'saldo' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, saldo WHERE (deleted.id = saldo.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''saldo''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'library' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, library WHERE (deleted.id = library.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''library''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'userid' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, userid WHERE (deleted.id = userid.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''userid''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'aa' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, aa WHERE (deleted.id = aa.parentid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''aa''.'            SELECT @status='Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'saldo1' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, saldo1 WHERE (deleted.id = saldo1.rekvid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''saldo1''.'            SELECT @status='Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigD_rekv ON dbo.rekv FOR DELETE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* CASCADE DELETES TO 'arv' */DELETE arv FROM deleted, arv WHERE deleted.id = arv.rekvid/* CASCADE DELETES TO 'nomenklatuur' */DELETE nomenklatuur FROM deleted, nomenklatuur WHERE deleted.id = nomenklatuur.rekvid/* CASCADE DELETES TO 'journal' */DELETE journal FROM deleted, journal WHERE deleted.id = journal.rekvid/* CASCADE DELETES TO 'asutus' */DELETE asutus FROM deleted, asutus WHERE deleted.id = asutus.rekvid/* CASCADE DELETES TO 'saldo' */DELETE saldo FROM deleted, saldo WHERE deleted.id = saldo.rekvid/* CASCADE DELETES TO 'library' */DELETE library FROM deleted, library WHERE deleted.id = library.rekvid/* CASCADE DELETES TO 'userid' */DELETE userid FROM deleted, userid WHERE deleted.id = userid.rekvid/* CASCADE DELETES TO 'aa' */DELETE aa FROM deleted, aa WHERE deleted.id = aa.parentid/* CASCADE DELETES TO 'saldo1' */DELETE saldo1 FROM deleted, saldo1 WHERE deleted.id = saldo1.rekvid/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigI_saldo ON dbo.saldo FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigU_saldo ON dbo.saldo FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_saldo1 ON dbo.saldo1 FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'rekv' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'            SELECT @status='Failed'        END    END/* PREVENT INSERTS IF NO MATCHING KEY IN 'asutus' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_saldo1 ON dbo.saldo1 FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF NO MATCHING KEY IN 'asutus' */IF UPDATE(asutusid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigU_sorder1 ON dbo.sorder1 FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'sorder2' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, sorder2 WHERE (deleted.id = sorder2.parentid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''sorder2''.'            SELECT @status='Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_sorder1
ON sorder1
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigD_sorder1 ON dbo.sorder1 FOR DELETE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* CASCADE DELETES TO 'sorder2' */DELETE sorder2 FROM deleted, sorder2 WHERE deleted.id = sorder2.parentid/* CASCADE DELETES TO 'arvtasu' */DELETE arvtasu FROM deleted, arvtasu WHERE deleted.id = arvtasu.sorderid/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigI_sorder2 ON dbo.sorder2 FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'sorder1' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM sorder1, inserted WHERE (sorder1.id = inserted.parentid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''sorder1''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigU_sorder2 ON dbo.sorder2 FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'sorder1' */IF UPDATE(parentid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM sorder1, inserted WHERE (sorder1.id = inserted.parentid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''sorder1''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_sorder2
ON sorder2
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigI_subkonto ON dbo.subkonto FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'library' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM library, inserted WHERE (library.id = inserted.kontoid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''library''.'            SELECT @status='Failed'        END    END/* PREVENT INSERTS IF NO MATCHING KEY IN 'asutus' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigU_subkonto ON dbo.subkonto FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'library' */IF UPDATE(kontoid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM library, inserted WHERE (library.id = inserted.kontoid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''library''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF NO MATCHING KEY IN 'asutus' */IF UPDATE(asutusid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM asutus, inserted WHERE (asutus.id = inserted.asutusid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''asutus''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_subkonto
ON subkonto
FOR INSERT
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_tooleping
ON dbo.tooleping
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER sp_getid_tuludkulud
ON tuludkulud
FOR INSERT 
AS
select id from inserted



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigU_userid ON dbo.userid FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'rekv' */IF UPDATE(rekvid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM rekv, inserted WHERE (rekv.id = inserted.rekvid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''rekv''.'                SELECT @status = 'Failed'            END    END/* PREVENT UPDATES IF DEPENDENT RECORDS IN 'journal' */IF UPDATE(id) AND @status<>'Failed'    BEGIN    IF (SELECT COUNT(*) FROM deleted, journal WHERE (deleted.id = journal.userid)) > 0        BEGIN            RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''journal''.'            SELECT @status='Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER TrigD_userid ON dbo.userid FOR DELETE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT DELETES IF DEPENDENT RECORDS IN 'journal' */IF (SELECT COUNT(*) FROM deleted, journal WHERE (deleted.id = journal.userid)) > 0    BEGIN    RAISERROR 44445 'Cannot delete or change record.  Referential integrity rules would be violated because related records exist in table ''journal''.'    SELECT @status='Failed'    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_userid
 ON userid
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_vorder1
On vorder1
FOR INSERT
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigI_vorder1 ON dbo.vorder1 FOR INSERT AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT INSERTS IF NO MATCHING KEY IN 'aa' */IF @status<>'Failed'    BEGIN    IF(SELECT COUNT(*) FROM inserted) !=   (SELECT COUNT(*) FROM aa, inserted WHERE (aa.id = inserted.kassaid))        BEGIN            RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''aa''.'            SELECT @status='Failed'        END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER TrigU_vorder1 ON dbo.vorder1 FOR UPDATE AS DECLARE @status char(10)  /* USED BY VALIDATION STORED PROCEDURES */SELECT @status='Succeeded'/* PREVENT UPDATES IF NO MATCHING KEY IN 'aa' */IF UPDATE(kassaid) AND @status<>'Failed'    BEGINIF (SELECT COUNT(*) FROM inserted) !=           (SELECT COUNT(*) FROM aa, inserted WHERE (aa.id = inserted.kassaid))            BEGIN                RAISERROR 44446 'Cannot add or change record.  Referential integrity rules require a related record in table ''aa''.'                SELECT @status = 'Failed'            END    END/* ROLLBACK THE TRANSACTION IF ANYTHING FAILED */IF @status='Failed'ROLLBACK TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER sp_getid_vorder2
ON vorder2
FOR INSERT 
AS
select id from inserted


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

