if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_ASUTUSkaibed]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_ASUTUSkaibed]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_calc_palgajaak]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_calc_palgajaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_calc_palk_jaak]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_calc_palk_jaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_calc_saldod]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_calc_saldod]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_calc_saldod1]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_calc_saldod1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_calc_saldod1_1]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_calc_saldod1_1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_calc_svod_saldod]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_calc_svod_saldod]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_change_konto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_change_konto]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_check_saldo_integrity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_check_saldo_integrity]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_check_subkonto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_check_subkonto]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_create_saldo1_tabel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_create_saldo1_tabel]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_create_saldo1_tabel1]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_create_saldo1_tabel1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_create_saldo_tabel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_create_saldo_tabel]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_kaibed]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_kaibed]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_kinniperiod]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_kinniperiod]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_klsaldo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_klsaldo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_klsaldo1]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_klsaldo1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_klsaldo_intproc]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_klsaldo_intproc]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_recalc_saldo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_recalc_saldo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_recalc_saldo1]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_recalc_saldo1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_recalc_saldo2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_recalc_saldo2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_saldo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_saldo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_saldo_intproc]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_saldo_intproc]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_save_copy]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_save_copy]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_update_palk_jaak]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_palk_jaak]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_update_pohikonto_saldo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_pohikonto_saldo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_update_pohikonto_saldo1]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_pohikonto_saldo1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_update_saldo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_saldo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_ASUTUSkaibed 
@rekv		int,
@kuu1		int,
@kuu2		int,
@aasta		int,
@konto		varchar(20),
@Asutus	varchar(254)
AS
declare 	@algKuu 	int,
	@loppKuu	int
select top 1 @algKuu = kuu from aasta where kinni = 1 order by kuu desc
set @algKuu = isnull (@algKuu,0)
if @algKuu < @kuu1 
	begin
		select curkaibed.asutusId1 as asutusid, asutus.nimetus as asutus, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
			curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curAsutusKaibed curkaibed inner join asutus on asutus.id = curkaibed.asutusId1
			where rekvid1 = @rekv 
			and kuu1 >= @kuu1
			and kuu1 <= @kuu2
			and aasta1 = @aasta
			and konto1 like @konto
			and asutus.nimetus like @asutus
		union
		select asutusId, asutus.nimetus as asutus, km.rekvid, km.kuu, @aasta as aasta, km.konto, 0 as deebet, 0 as kreedit
			from subkontodematrix km inner join asutus on asutus.id = km.asutusId
			where km.rekvid = @rekv
			and kuu >= @Kuu1
			and kuu <= @kuu2
			and konto like @konto	
			and asutus.nimetus like @asutus
	end
if @algkuu >= @kuu1 AND @kuu2 > @kuu1
	begin
		select asutusid, asutus, rekvid, kuu, aasta, konto, deebet as deebet, kreedit as kreedit from 
			(select asutusId, asutus.nimetus as asutus, saldo1.rekvid, datepart(month,period) as kuu, datepart (year, period) as aasta, konto, dbkaibed as deebet, krkaibed as kreedit 
				from saldo1 inner join asutus on asutus.id = saldo1.asutusId
				where datepart(month,period) >= @kuu1 and datepart (year, period) = @aasta and datepart (month, period) <= @algkuu
			union 			
			select curkaibed.asutusId1 as asutusId, asutus.nimetus as asutus, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curAsutuskaibed curkaibed inner join asutus on asutus.id = curKaibed.asutusId1
				where rekvid1 = @rekv 
				and kuu1 >= @Algkuu + 1
				and kuu1 <= @kuu2
				and aasta1 = @aasta
			union
			select asutusId, asutus.nimetus as asutus, km.rekvid, km.kuu, @aasta as aasta, km.konto, 0 as deebet, 0 as kreedit
				from subkontodematrix km inner join asutus on asutus.id = km.asutusid
				where km.rekvid = @rekv
				and kuu >= @Kuu1
				and kuu <= @kuu2 ) tmpSaldo
		WHERE konto like @konto
		and  asutus like @asutus

	end

if @algkuu >= @kuu1 AND @kuu2 = @kuu1
	begin
		select asutusid, asutus, rekvid, kuu, aasta, konto, sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select curkaibed.asutusId1 as asutusId, asutus.nimetus as asutus, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curAsutuskaibed curkaibed inner join asutus on asutus.id = curKaibed.asutusId1
				where rekvid1 = @rekv 
				and kuu1 >= @kuu1
				and kuu1 <= @kuu2
				and aasta1 = @aasta
			union
			select asutusId, asutus.nimetus as asutus, km.rekvid, km.kuu, @aasta as aasta, km.konto, 0 as deebet, 0 as kreedit
				from subkontodematrix km inner join asutus on asutus.id = km.asutusid
				where km.rekvid = @rekv
				and kuu >= @Kuu1
				and kuu <= @kuu2 ) tmpSaldo
		WHERE konto like @konto
		and  asutus like @asutus
		group by asutusId, asutus, rekvid, kuu, aasta, konto

	end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_ASUTUSkaibed]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_ASUTUSkaibed]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE sp_calc_palgajaak 
@rekvId	int,
@kpv1		datetime,
@kpv2		datetime,
@Isik1		int,
@isik2		int	
AS
declare @id		int,
	@lKpv1		datetime,
	@lKpv2		datetime,
	@kuu		smallint,
	@aasta		smallint
declare cur_lepingud cursor
	for select   tooleping.id from asutus inner join tooleping on tooleping.parentId = asutus.id
		where asutus.id >= @Isik1
		and  asutus.id <= @Isik2
		and asutus.rekvid = @rekvid
	
open cur_lepingud
fetch cur_lepingud into @id
while @@fetch_status = 0
	begin
		select @kuu = datepart ( month, @kpv1), @aasta = datepart ( year, @kpv1)
		while datepart ( month, @kpv2) >= @kuu and datepart ( year, @kpv2 ) >= @aasta
			begin
				select @lKpv1 = '01.'+cast ( @kuu as varchar (2) ) +'.'+cast ( @aasta as varchar (4)), @lkpv2 = dateadd ( month, 1,@lKpv1) - 1
				exec sp_update_palk_jaak @lKpv1,@lKpv2, @rekvId, @id 					
				select @kuu = @kuu + 1
					if @kuu > 12
						select @kuu = 1, @aasta = @aasta + 1	
				select @kuu as kuu, @aasta as aasta			
			end  	

		
			fetch cur_lepingud into @id
	end
close cur_lepingud
deallocate cur_lepingud




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_palgajaak]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_palgajaak]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE sp_calc_palk_jaak 
@Kuu		smallint,
@Aasta		smallInt,
@leping		int
AS
declare 		@lastPeriodJaak	money,
		@arv			money,
		@kinni			money,
		@tulumaks		money,
		@PrevKuu		smallint,
		@PrevAasta		smallint,
		@id			int

update palk_jaak set jaak = 0 where kuu = @kuu and aasta = @aasta and lepingid = @leping
set @PrevKuu = @kuu - 1
	if @Prevkuu < 1
		select @Prevkuu = 12, @Prevaasta = @aasta - 1
	else
		set @PrevAasta = @aasta

select @LastPeriodJaak = jaak from palk_jaak where lepingId = @leping and kuu = @prevKuu and aasta = @prevAasta
set @LastPeriodJaak = isnull (@LastPeriodJaak,0)
select @arv = arvestatud, @Kinni = kinni, @Tulumaks = tulumaks, @id = id from palk_jaak where lepingId = @leping and kuu = @Kuu and aasta = @Aasta
update palk_jaak set jaak = @lastPeriodJaak + @arv - @kinni - @tulumaks where id = @id



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_palk_jaak]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_palk_jaak]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_calc_saldod
@rekvId		int,
@kpv1			datetime,
@kpv2			datetime,
@konto			varchar(20)
AS
declare @deebet	varchar(20),
	@kreedit 	varchar(20),
	@summa	money,
	@period	varchar(20),
	@paev		datetime,
	@saldoId	int,
	@kpv		datetime,
	@kood		varchar(20),
	@algsaldo 	money,
	@loppsaldo	money,
	@dbkaibed	money,	
	@krkaibed	money,
	@viimanekonto	varchar(20),
	@liik		smallint,
	@pohikonto	varchar ( 20 ),
	@cMonth	varchar(2),
	@nMonth	int,
	@aasta		int
	

declare cur_kontod cursor
for select   kood, kontoinf.liik, kontoinf.pohikonto  from library inner join kontoinf on kontoinf.parentid = library.id 
	where rekvid = @rekvid
	and library = 'KONTOD'
	and library.kood like @konto
	and kontoinf.liik <> 2
	order by library.kood
	
/*
and datepart ( year, kontoinf.aasta) = datepart ( year, @kpv1)
*/
set @loppsaldo = 0

update saldo set 
	dbkaibed = 0,
	krkaibed = 0
	where datepart ( year, period ) >= datepart (  year, @kpv1 )
	and datepart ( month, period ) >= datepart ( month, @kpv1 )  
	and datepart ( year, period ) <= datepart (  year, @kpv2 )
	and datepart ( month, period ) <= datepart ( month, @kpv2 )
	and konto like @konto

open cur_kontod
fetch cur_kontod into @kood, @liik, @pohikonto
while @@fetch_status = 0
begin
	
	if datepart ( month,@kpv1 ) = 1 
		begin
			select @algsaldo = algsaldo from kontoinf inner join library on library.id = kontoinf.parentid  where library.kood = @kood and kontoinf.aasta = datepart (year, @kpv1 ) and library.rekvId = @rekvId			
			select top 1 @saldoId = id from saldo 
					where konto = @kood 
					and  datepart ( year, period )   = datepart ( year, @kpv1) 
					and  datepart ( month , period )  = 1  
					and rekvid = @rekvId
					order by id desc
			set @saldoid = isnull(@saldoid,0)
			if @saldoId = 0
				begin
					set @aasta = datepart (year, @kpv1 )
					exec sp_create_saldo_tabel @rekvId, @aasta, @konto

					select top 1 @saldoId = id from saldo 
					where konto = @kood 
					and  datepart ( year, period )   = datepart ( year, @kpv1) 
					and  datepart ( month , period )  = 1  
					and rekvid = @rekvId
					order by id desc
				end
			update saldo set saldo = @algsaldo 
				where id = @Saldoid
		end
		declare cur_lausendid_db cursor
			for select   str ( datepart ( year,kpv ),4 )+  str ( datepart ( month,kpv ),2)  period,  sum ( summa ) as summa from curjournal 
			where  datepart ( year, kpv )  >= datepart ( year, @kpv1 ) 
			and datepart ( month, kpv ) >= datepart ( month, @kpv1 )
			and datepart ( year, kpv )  <= datepart ( year, @kpv2 ) 
			and datepart ( month, kpv )  <= datepart ( month, @kpv2 ) 
			and ltrim ( rtrim ( deebet) )  = ltrim ( rtrim( @kood ) ) 
			and rekvid = @rekvid
			group by str ( datepart ( year, kpv ),4 )+  str ( datepart ( month,kpv ),2 )
			order by str ( datepart ( year, kpv ),4 )+ str ( datepart ( month,kpv ),2 )  
	
		open cur_lausendid_db
		fetch cur_lausendid_db into @period,  @summa
		while @@fetch_status = 0
			begin

			select  @saldoId = id  from saldo 
				where str ( datepart (year,period ) ,4)+ str ( datepart ( month,period ),2 ) = @period
				and konto = @kood
				and rekvId = @rekvId

				update saldo set 
				dbkaibed = dbkaibed + @summa
				where id = @saldoId

				set @dbKaibed = @summa
				fetch cur_lausendid_db into @period,  @summa
			end
		close cur_lausendid_db 
		deallocate cur_lausendid_db

		declare cur_lausendid_kr cursor
		for select   str ( datepart ( year,kpv ),4 )+str ( datepart ( month,kpv ),2 )  period,  sum ( summa ) as summa from curjournal 
		where  datepart ( year, kpv )  >= datepart ( year, @kpv1 )
		and datepart ( month, kpv ) >= datepart ( month, @kpv1 )
		and datepart ( year, kpv)  <= datepart ( year, @kpv2 )
		and datepart ( month, kpv ) <= datepart ( month, @kpv2)
		and  ltrim ( rtrim ( kreedit) )  = ltrim ( rtrim ( @kood ) ) 
		and rekvid = @rekvId
		group by str ( datepart ( year, kpv ),4 )+  str ( datepart ( month,kpv ),2 )
		order by str ( datepart ( year, kpv ),4 )+ str ( datepart ( month,kpv ),2 )  

		open cur_lausendid_kr 
		fetch cur_lausendid_kr into @period,  @summa
		while @@fetch_status = 0
		begin
			select  @saldoId = id  from saldo 
			where str ( datepart ( year,period ) ,4)+ str ( datepart ( month,period ),2 ) = @period
			and konto = @kood
			and rekvId = @rekvId
	
			update saldo set 
			krkaibed = krkaibed + @summa
			where id = @saldoId
			set @krkaibed = @summa			
		fetch cur_lausendid_kr into @period,  @summa	
	end
	close cur_lausendid_kr  
	deallocate cur_lausendid_kr
	fetch cur_kontod into @kood, @liik, @pohikonto
end
close cur_kontod
deallocate cur_kontod
exec sp_recalc_saldo @rekvId, @kpv1, @kpv2, @konto

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_saldod]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_saldod]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_calc_saldod1
@rekvId		int,
@kpv1			datetime,
@kpv2			datetime,
@konto			varchar(20)
AS
declare @deebet	varchar(20),
	@kreedit 	varchar(20),
	@summa	money,
	@period	varchar(20),
	@paev		datetime,
	@saldoId	int,
	@kpv		datetime,
	@kood		char(20),
	@algsaldo 	money,
	@loppsaldo	money,
	@dbkaibed	money,	
	@krkaibed	money,
	@viimanekonto	varchar(20),
	@liik		smallint,
	@pohikonto	varchar ( 20 ),
	@cMonth	varchar(2),
	@nMonth	int,
	@aasta		int,
	@asutusid	int
	

set @loppsaldo = 0

update saldo1 set 
	dbkaibed = 0,
	krkaibed = 0
	where datepart ( year, period ) >= datepart (  year, @kpv1 )
	and datepart ( month, period ) >= datepart ( month, @kpv1 )  
	and datepart ( year, period ) <= datepart (  year, @kpv2 )
	and datepart ( month, period ) <= datepart ( month, @kpv2 )
	and konto like @konto

declare cur_kontod cursor
for select   kood, kontoinf.liik, kontoinf.pohikonto, subkonto.asutusId  from library inner join kontoinf on kontoinf.parentid = library.id 
	inner join subkonto on subkonto.kontoid = library.id
	where rekvid = @rekvid
	and ltrim(rtrim(upper(library))) = 'KONTOD'
	and library.kood like @konto
	and kontoinf.liik <> 2
	order by library.kood, asutusid
	
/*
and datepart ( year, kontoinf.aasta) = datepart ( year, @kpv1)
*/


select @konto, @rekvId

select   kood, kontoinf.liik, kontoinf.pohikonto, subkonto.asutusId  from library inner join kontoinf on kontoinf.parentid = library.id 
	inner join subkonto on subkonto.kontoid = library.id
	where rekvid = @rekvid
	and ltrim(rtrim(upper(library))) = 'KONTOD'
	and library.kood like @konto
	and kontoinf.liik <> 2
	order by library.kood, asutusid

open cur_kontod
fetch cur_kontod into @kood, @liik, @pohikonto, @asutusId
while @@fetch_status = 0
begin
	PRINT @KOOD
	
	if datepart ( month,@kpv1 ) = 1 
		begin
			select @algsaldo = algsaldo from subkonto inner join library on library.id = subkonto.kontoid 
				where library.kood = @kood 
				and subkonto.aasta = datepart (year, @kpv1 ) 
				and library.rekvId = @rekvId
				and asutusId = @asutusId			
/*			select "algsaldo  " = @algsaldo, @kood, @asutusid */
			select top 1 @saldoId = id from saldo1 
					where konto = @kood 
					and  datepart ( year, period )   = datepart ( year, @kpv1) 
					and  datepart ( month , period )  = 1  
					and rekvid = @rekvId
					and asutusId = @asutusId
					order by id desc
			set @saldoid = isnull(@saldoid,0)
			if @saldoId = 0
				begin
					set @aasta = datepart (year, @kpv1 )
					print 'uus kiri kontole ' + @kood + str (@asutusId)				
					exec sp_create_saldo1_tabel @rekvId, @aasta, @konto

					select top 1 @saldoId = id from saldo1 
					where konto = @kood 
					and  datepart ( year, period )   = datepart ( year, @kpv1) 
					and  datepart ( month , period )  = 1  
					and rekvid = @rekvId
					and asutusid = @asutusId
					order by id desc
				end
			set @algsaldo = isnull(@algsaldo,0)
			update saldo1 set saldo = @algsaldo 
				where id = @Saldoid
		end
		declare cur_lausendid_db cursor
			for select   str ( datepart ( year,kpv ),4 )+  str ( datepart ( month,kpv ),2)  period,  sum ( summa ) as summa from curjournal 
			where  datepart ( year, kpv )  >= datepart ( year, @kpv1 ) 
			and datepart ( month, kpv ) >= datepart ( month, @kpv1 )
			and datepart ( year, kpv )  <= datepart ( year, @kpv2 ) 
			and datepart ( month, kpv )  <= datepart ( month, @kpv2 ) 
			and ltrim ( rtrim ( deebet) )  = ltrim ( rtrim( @kood ) ) 
			and rekvid = @rekvid
			and asutusId = @asutusId
			group by str ( datepart ( year, kpv ),4 )+  str ( datepart ( month,kpv ),2 )
			order by str ( datepart ( year, kpv ),4 )+ str ( datepart ( month,kpv ),2 )  

			select   str ( datepart ( year,kpv ),4 )+  str ( datepart ( month,kpv ),2)  period,  sum ( summa ) as summa from curjournal 
			where  datepart ( year, kpv )  >= datepart ( year, @kpv1 ) 
			and datepart ( month, kpv ) >= datepart ( month, @kpv1 )
			and datepart ( year, kpv )  <= datepart ( year, @kpv2 ) 
			and datepart ( month, kpv )  <= datepart ( month, @kpv2 ) 
			and ltrim ( rtrim ( deebet) )  = ltrim ( rtrim( @kood ) ) 
			and rekvid = @rekvid
			and asutusId = @asutusId
			group by str ( datepart ( year, kpv ),4 )+  str ( datepart ( month,kpv ),2 )
			order by str ( datepart ( year, kpv ),4 )+ str ( datepart ( month,kpv ),2 ) 	
		open cur_lausendid_db
		fetch cur_lausendid_db into @period,  @summa
		while @@fetch_status = 0
			begin

			select  @saldoId = id  from saldo1 
				where str ( datepart ( year,period ) ,4)+ str ( datepart ( month,period ),2 ) = @period
				and konto = @kood
				and rekvId = @rekvId
				and asutusId = @asutusId
				update saldo1 set 
				dbkaibed = dbkaibed + @summa
				where id = @saldoId

				set @dbKaibed = @summa
				fetch cur_lausendid_db into @period,  @summa
			end
		close cur_lausendid_db 
		deallocate cur_lausendid_db

		declare cur_lausendid_kr cursor
		for select   str ( datepart ( year,kpv ),4 )+str ( datepart ( month,kpv ),2 )  period,  sum ( summa ) as summa from curjournal 
		where  datepart ( year, kpv )  >= datepart ( year, @kpv1 )
		and datepart ( month, kpv ) >= datepart ( month, @kpv1 )
		and datepart ( year, kpv)  <= datepart ( year, @kpv2 )
		and datepart ( month, kpv ) <= datepart ( month, @kpv2)
		and  ltrim ( rtrim ( kreedit) )  = ltrim ( rtrim ( @kood ) ) 
		and rekvid = @rekvId
		and asutusId = @asutusId
		group by str ( datepart ( year, kpv ),4 )+  str ( datepart ( month,kpv ),2 )
		order by str ( datepart ( year, kpv ),4 )+ str ( datepart ( month,kpv ),2 ) 
 
select   str ( datepart ( year,kpv ),4 )+str ( datepart ( month,kpv ),2 )  period,  sum ( summa ) as summa from curjournal 
		where  datepart ( year, kpv )  >= datepart ( year, @kpv1 )
		and datepart ( month, kpv ) >= datepart ( month, @kpv1 )
		and datepart ( year, kpv)  <= datepart ( year, @kpv2 )
		and datepart ( month, kpv ) <= datepart ( month, @kpv2)
		and  ltrim ( rtrim ( kreedit) )  = ltrim ( rtrim ( @kood ) ) 
		and rekvid = @rekvId
		and asutusId = @asutusId
		group by str ( datepart ( year, kpv ),4 )+  str ( datepart ( month,kpv ),2 )
		order by str ( datepart ( year, kpv ),4 )+ str ( datepart ( month,kpv ),2 )

		open cur_lausendid_kr 
		fetch cur_lausendid_kr into @period,  @summa
		while @@fetch_status = 0
		begin
			select  @saldoId = id  from saldo1 
			where str ( datepart ( year,period ) ,4)+ str ( datepart ( month,period ),2 ) = @period
			and konto = @kood
			and rekvId = @rekvId
			and asutusId = @asutusId
	
			update saldo1 set 
			krkaibed = krkaibed + @summa
			where id = @saldoId
			set @krkaibed = @summa			
		fetch cur_lausendid_kr into @period,  @summa	
	end
	close cur_lausendid_kr  
	deallocate cur_lausendid_kr
	fetch cur_kontod into @kood, @liik, @pohikonto, @asutusId
end
close cur_kontod
deallocate cur_kontod
exec sp_recalc_saldo1 @rekvId, @kpv1, @kpv2, @konto
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_saldod1]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_saldod1]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_calc_saldod1_1
@rekvId		int,
@kpv1			datetime,
@kpv2			datetime,
@konto			varchar(20)
AS
declare @deebet	char(20),
	@kreedit 	char(20),
	@summa	money,
	@period	varchar(20),
	@paev		datetime,
	@saldoId	int,
	@kpv		datetime,
	@kood		char(20),
	@algsaldo 	money,
	@loppsaldo	money,
	@dbkaibed	money,	
	@krkaibed	money,
	@viimanekonto	varchar(20),
	@liik		smallint,
	@pohikonto	char ( 20 ),
	@cMonth	char(2),
	@nMonth	int,
	@aasta		int,
	@asutusid	int
	

select @konto, @rekvId

select   kood, kontoinf.liik, kontoinf.pohikonto, subkonto.asutusId  from library inner join kontoinf on kontoinf.parentid = library.id 
	inner join subkonto on subkonto.kontoid = library.id
	where rekvid = @rekvid
	and ltrim(rtrim(upper(library))) = 'KONTOD'
	and library.kood like @konto
	and kontoinf.liik <> 2
	order by library.kood, asutusid


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_saldod1_1]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_saldod1_1]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_calc_svod_saldod
@rekvId		int,
@kuu			int,
@aasta			int,
@konto		varchar(20)

AS
declare 	@saldoId	int,
	@kpv		datetime,
	@kood		varchar(20),
	@algsaldo	money,
	@dbkaibed 	money,
	@krkaibed	money,
	@pohikonto	varchar


select @pohikonto = kood  from library inner join kontoinf on kontoinf.parentId = library.id 
	where left ( kood, 3) = left ( @konto , 3)  and kontoinf.liik = 2 and kontoinf.aasta = @aasta
set @pohikonto = isnull ( @pohikonto, space(1))
if len ( ltrim ( rtrim ( @pohikonto) )  ) > 1
	begin 
		select @algsaldo = sum ( saldo ) , @dbkaibed = sum ( dbkaibed ) , @krkaibed = sum ( krkaibed ) 
			from saldo
		where konto in (  select kood 
			from library inner join kontoinf on kontoinf.parentId = library.id 
			where left ( kood, 3) = left ( @konto , 3)  and kontoinf.liik = 3 and kontoinf.aasta = @aasta )

		set @algsaldo = isnull ( @algsaldo , 0)
		set @dbkaibed = isnull ( @dbkaibed , 0)
		set @krkaibed = isnull ( @krkaibed, 0)

		update saldo set 
			saldo = @algsaldo,
			dbkaibed = @dbkaibed,
			krkaibed = @krkaibed
			where konto = @konto

	end























GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_svod_saldod]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_calc_svod_saldod]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_change_konto 
@vanakonto 	varchar( 20 ),
@uuskonto	varchar ( 20 ) 
AS
declare @liik	int,
	@count	int
print @vanakonto + @uuskonto
select @liik = liik from library inner join kontoinf on kontoinf.parentid = library.id where ltrim ( rtrim ( library.kood ) )  = ltrim ( rtrim ( @uuskonto ) )
set @liik = isnull(@liik,0)
if @liik = 2 	
	begin
		print 'pohikonto'
		update kontoinf set pohikonto = @uuskonto where ltrim ( rtrim ( pohikonto) )  = ltrim ( rtrim ( @vanakonto) ) 
	end
update saldo set konto = @uuskonto where ltrim ( rtrim ( konto ) )  = ltrim ( rtrim ( @vanakonto ) ) 

select top 1 @count = id from saldo1 where ltrim ( rtrim ( konto ) )  = ltrim( rtrim ( @vanakonto) )  order by id desc
set @count = isnull ( @count, 0)
if @count > 0
	update saldo1 set konto = @uuskonto where ltrim( rtrim ( konto ) )  = ltrim ( rtrim ( @vanakonto ) ) 

select top 1 @count = id from lausend where deebet = ltrim ( rtrim ( @vanakonto) )  or ltrim ( rtrim ( kreedit) ) = ltrim ( rtrim ( @vanakonto ) ) order by id desc
set @count = isnull ( @count, 0)
if @count > 0
	begin
		update lausend set deebet = @uuskonto where ltrim ( rtrim ( deebet ) ) = ltrim ( rtrim ( @vanakonto ) )
		update lausend set kreedit = @uuskonto where ltrim ( rtrim ( kreedit) ) = ltrim ( rtrim ( @vanakonto ) )
	end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_change_konto]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_change_konto]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_check_saldo_integrity  
@Kuu 	int,
@aasta int
AS

select saldo.konto, saldo.saldo-isnull(saldo1tmp.saldo,0) as saldo,
saldo.dbkaibed-isnull(saldo1tmp.dbkaibed,0) as dbkaibed,
saldo.krkaibed-isnull(saldo1tmp.krkaibed,0) as krkaibed
from saldo full outer join (select saldo1.konto, sum(saldo1.saldo) as saldo, 
sum (saldo1.dbkaibed) as dbkaibed, sum (saldo1.krkaibed) as krkaibed  
from saldo1 
where datepart (month,saldo1.period ) = @kuu
and datepart (year, saldo1.period) = @aasta
group by saldo1.konto) saldo1tmp
on saldo.konto = saldo1tmp.konto
where
datepart (month,saldo.period ) = @kuu 
and datepart (year, saldo.period) = @aasta
and (saldo.saldo <> saldo1tmp.saldo
or saldo.dbkaibed <> saldo1tmp.dbkaibed
or saldo.krkaibed <> saldo1tmp.krkaibed)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_check_saldo_integrity]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_check_saldo_integrity]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_check_subkonto 
@kontoid 	int,
@asutusId	int
AS
declare @id	int,
	@konto	varchar(20),
	@YEAR INT,
	@REKViD	INT
select @id = id from subkonto 
	where kontoid = @kontoid 
	and asutusId = @asutusid

set @id = isnull(@id, 0)
if @id = 0
	begin
		set @year = datepart (year, getdate())
		insert into subkonto (kontoid, asutusid, aasta, algsaldo) values (@kontoid, @asutusid, @year, 0)
		select @konto = kood, @rekvid = rekvid from library where id = @id
		exec sp_create_saldo1_tabel1 @rekvId, @year, @konto, @asutusId	
	end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_check_subkonto]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_check_subkonto]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_create_saldo1_tabel 
@rekvId	int,
@aasta		int,
@konto		varchar ( 20) 
AS
declare @nMonth int,
	@cMonth	varchar(20),
	@kpv	datetime,
	@kood	varchar ( 20 ),
	@saldoid int,
	@cKpv	varchar ( 20 ),
	@asutusId	int

declare cur_konto cursor
for select   kood, asutusId  from library inner join kontoinf on kontoinf.parentid = library.id 
	inner join subkonto on subkonto.kontoid = library.id
	where rekvid = @rekvid
	and library = 'KONTOD'
	and kood like @konto
	order by library.kood

open cur_konto
fetch cur_konto into @kood, @asutusId
while @@fetch_status = 0
begin
	set @nMonth = 1
	while @nMonth < 13
		begin
			set @cMonth = ltrim ( rtrim ( str ( @nMonth ,2) ) ) 
			if len ( @cMonth ) = 1
				set @cMonth = '0'+@cMonth
			
			set @kpv = CAST ( str (@aasta, 4) + @cMonth +  '01'  AS DATETIME )			

			select  @saldoId =count  ( id )  from saldo1 
			where datepart ( year , period) = datepart ( year, @kpv )
			and datepart ( month, period ) = datepart ( month , @kpv)
			and konto = @kood
			and rekvId = @rekvId
			and asutusId = @asutusId
			set @SaldoId =  isnull(@SaldoId,0)
			if  @SaldoId = 0
				begin
					print 'uus kiri kontole ' + @kood + str (@asutusId)+ 'period ' + @cMonth + str(@Aasta)				
					insert into saldo1  ( rekvid, asutusid, period, konto, saldo ) values (@rekvId, @asutusId, @KPV, @kood, 0)
				end
			set @nMonth = @nMonth + 1				
		end
	fetch cur_konto into @kood, @asutusid
end
close cur_konto
deallocate cur_konto







GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo1_tabel]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo1_tabel]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE sp_create_saldo1_tabel1 
@rekvId	int,
@aasta		int,
@konto		varchar(20),
@asutusid	int
AS
declare @nMonth int,
	@cMonth	varchar(20),
	@kpv	datetime,
	@id	int
select  top 1  id   from saldo1 
where asutusid = @asutusid 
and konto = @konto 
and rekvId = @rekvId
order by id desc
if @@ROWCOUNT  < 1
begin
	set @nMonth = 1
	while @nMonth < 13
	begin
		set @cMonth = ltrim ( rtrim ( str ( @nMonth ,2) ) ) 
		if len ( @cMonth ) = 1
			set @cMonth = '0'+@cMonth			
		set @kpv = CAST ( str (@aasta, 4) + @cMonth +  '01'  AS DATETIME )			
		insert into saldo1  ( rekvid, asutusid, period, konto, saldo ) values (@rekvId, @asutusId, @KPV, @konto, 0)
		set @nMonth = @nMonth + 1				
	end
end









GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo1_tabel1]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo1_tabel1]  TO [dbadmin]
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo1_tabel1]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo1_tabel1]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_create_saldo_tabel 
@rekvId	int,
@aasta		int,
@konto		varchar ( 20) 
AS
declare @nMonth int,
	@cMonth	varchar(20),
	@kpv	datetime,
	@kood	varchar ( 20 ),
	@saldoid int,
	@cKpv	varchar ( 20 )

declare cur_konto cursor
for select   kood  from library inner join kontoinf on kontoinf.parentid = library.id 
	where rekvid = @rekvid
	and library = 'KONTOD'
	and kood like @konto
	order by library.kood

open cur_konto
fetch cur_konto into @kood
while @@fetch_status = 0
begin
	set @nMonth = 1
	while @nMonth < 13
		begin
			set @cMonth = ltrim ( rtrim ( str ( @nMonth ,2) ) ) 
			if len ( @cMonth ) = 1
				set @cMonth = '0'+@cMonth
			
			set @kpv = CAST ( str (@aasta, 4) + @cMonth +  '01'  AS DATETIME )			

			select  @saldoId =count  ( id )  from saldo 
			where datepart ( year , period) = datepart ( year, @kpv )
			and datepart ( month, period ) = datepart ( month , @kpv)
			and konto = @kood
			and rekvId = @rekvId

			set @SaldoId =  isnull(@SaldoId,0)
			if  @SaldoId = 0
				insert into saldo (rekvid, period, konto, saldo ) values (@rekvId, @KPV, @kood, 0)
			set @nMonth = @nMonth + 1				
		end
	fetch cur_konto into @kood
end
close cur_konto
deallocate cur_konto





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo_tabel]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_create_saldo_tabel]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_kaibed 
@rekv		int,
@kuu1		int,
@kuu2		int,
@aasta		int,
@konto		varchar(20)
AS
declare 	@algKuu 	int,
	@loppKuu	int
select top 1 @algKuu = kuu from aasta where kinni = 1 order by kuu desc
set @algKuu = isnull (@algKuu,0)
if @algKuu < @kuu1 
	begin
		select curkaibed.rekvid1, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
			curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed 
			where rekvid1 = @rekv 
			and kuu1 >= @kuu1
			and kuu1 <= @kuu2
			and aasta1 = @aasta
			and konto1 like @konto
		union
		select km.rekvid, km.kuu, @aasta as aasta, km.konto, 0 as deebet, 0 as kreedit
			from kontodematrix km
			where rekvid = @rekv
			and kuu >= @Kuu1
			and kuu <= @kuu2
			and konto like @konto	
	end
if @algkuu >= @kuu1 and @kuu2 > @kuu1
	begin
		if @kuu2 < @algkuu
			set @algkuu = @kuu2
		select rekvid, kuu, aasta, konto, deebet as deebet, kreedit as kreedit from 
			(select rekvid, datepart(month,period) as kuu, datepart (year, period) as aasta, konto, dbkaibed as deebet, krkaibed as kreedit from saldo 
				where datepart(month,period) >= @kuu1 and datepart (year, period) = @aasta and datepart (month, period) <= @algkuu and konto like @konto
			union 			
			select curkaibed.rekvid1, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed 
				where rekvid1 = @rekv 
				and kuu1 >= @Algkuu + 1
				and kuu1 <= @kuu2
				and aasta1 = @aasta
				and konto1 like @konto
			union
			select km.rekvid, km.kuu, @aasta as aasta, km.konto, 0 as deebet, 0 as kreedit
				from kontodematrix km
				where rekvid = @rekv
				and kuu >= @Kuu1
				and kuu <= @kuu2 and konto like @konto ) tmpSaldo
	end

if @algkuu >= @kuu1 and @kuu2 = @kuu1
	begin
		if @kuu2 < @algkuu
			set @algkuu = @kuu2
		select rekvid, kuu, aasta, konto, deebet as deebet, kreedit as kreedit from 
			(select curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed 
				where rekvid1 = @rekv 
				and kuu1 >= @kuu1
				and kuu1 <= @kuu2
				and aasta1 = @aasta
				and  konto1 like @konto
			union
			select km.rekvid, km.kuu, @aasta as aasta, km.konto, 0 as deebet, 0 as kreedit
				from kontodematrix km
				where rekvid = @rekv
				and kuu >= @Kuu1
				and kuu <= @kuu2 
				and  konto like @konto) tmpSaldo
	end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_kaibed]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_kaibed]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_kinniperiod  
@rekvid	int,
@kuu		int,
@aasta		int
AS
DECLARE 	@curSaldo CURSOR,
		@deebet	money,
		@kreedit 	money,
		@id		int,
		@konto		varchar (20),
		@kpv		datetime,
		@dbKaibed	money,
		@krkaibed	money,
		@asutusId	int,
		@algkuu	int,
		@month	int,
		@year		int,
		@day		int,
		@count		int

/*exec sp_create_saldo1_tabel @rekvId, @aasta, '%' */

/*
EXECUTE sp_saldo_intproc @rekvId, @kuu, @aasta, @curSaldo OUTPUT  */


select top 1 @algkuu = kuu from aasta where kinni = 1 and aasta = @aasta order by kuu desc
set @algkuu = isnull (@algkuu, 0)
if @algkuu < @kuu and @algkuu > 0
	begin

		SET @curSaldo = CURSOR FORWARD_ONLY STATIC
		 FOR select rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select rekvid, konto, datepart(month,period) as kuu, datepart (year, period) as aasta,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo  where rekvid = @rekvid
			union 
			select curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed  where kuu1 > @algkuu
				and kuu1 <= @Kuu and aasta1 = @aasta and rekvid1 = @rekvid)  tmpSaldo
			where kuu = @algKuu and aasta = @aasta
			and rekvid = @rekvid
			group by rekvid, kuu, aasta, konto

	end
if @algkuu = 0
	begin

set @algkuu = 1
		SET @curSaldo = CURSOR FORWARD_ONLY STATIC
		for select rekvid, kuu, aasta, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select library.rekvId, 0 as kuu, kontoinf.aasta,library.kood as konto,
			kontoinf.algsaldo as deebet, cast(0 as money) as kreedit from library inner join kontoinf
			on library.id = kontoinf.parentid where kontoinf.aasta = @aasta and library.rekvid = @rekvid
			union
			select curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed where kuu1 <= @Kuu and aasta1 = @aasta and rekvid1 = @rekvid) tmpSaldo
			where rekvid = @rekvid
			group by rekvid, kuu, aasta, konto


	end
if @algkuu >= @kuu
	begin

		set @algkuu = @kuu
		SET @curSaldo = CURSOR FORWARD_ONLY STATIC 
		for select rekvid, kuu, aasta, konto,  deebet, kreedit  from 
			(select rekvid, konto, datepart(month,period) as kuu, datepart (year, period) as aasta,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo where rekvid = @rekvid) tmpSaldo
		where kuu = @algKuu and aasta = @aasta
		and rekvid = @rekvid
	end

open @curSaldo

set @count = 0
		FETCH next from @curSaldo into @rekvid, @kuu, @aasta, @konto, @deebet, @kreedit
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			set @count = @count + 1
			select @dbkaibed = deebet, @krkaibed = kreedit from curKaibed where rekvid1 = @rekvId and kuu1 = @kuu and aasta1 = @aasta and konto1 = @konto
			select @dbkaibed = isnull (@dbkaibed,0), @krkaibed = isnull (@krkaibed,0)
			select @id = id from saldo where konto = @konto and datepart (month, period) = @kuu and datepart (year , period) = @aasta and rekvId = @rekvid
			if @@rowcount = 0
				set @id = 0
			if @id = 0
				begin
					set @kpv = str (@aasta,4) + case  when @kuu < 10 and @kuu > 0 then '0'+str (@kuu,1) when @kuu = 0 then '01' else str (@kuu,2)  end + '01'
					insert into saldo (rekvid, period, konto, saldo, dbkaibed, krkaibed) values (@rekvId, @kpv, @konto, @deebet - @kreedit, @dbkaibed, @krkaibed)
				end
			else
				begin
					update saldo set 
						saldo  = @deebet- @kreedit, 
						dbkaibed = @dbkaibed,
						krkaibed = @krkaibed	
						where id = @id										
				end 
	
   	
			FETCH next from @curSaldo into @rekvid, @kuu, @aasta, @konto, @deebet, @kreedit
		END
		CLOSE @curSaldo
		DEALLOCATE @curSaldo


/*
DECLARE 	@curKlSaldo CURSOR

EXECUTE sp_klsaldo_intproc @rekvId, @kuu, @aasta, @curKlSaldo OUTPUT 

*/

select top 1 @algkuu = kuu from aasta where kinni = 1 and aasta = @aasta order by kuu desc
set @algkuu = isnull (@algkuu, 0)
if @algkuu > 1
	begin
		if @algkuu > @kuu
			set @algkuu = @kuu - 1
		declare  curKlSaldo  cursor 
		for select asutusId, rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select asutusId, rekvid,  datepart(month,period) + 1 as kuu, datepart (year, period) as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 
			where datepart(month,period) = @algkuu - 1
			and datepart(year,period) = @aasta and rekvid = @rekvid
			union 
			select curkaibed.asutusid1 as asutusId, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curasutuskaibed curkaibed  where kuu1 >= @algkuu
				and kuu1 <= @Kuu and aasta1 = @aasta and rekvid1 = @rekvid )  tmpSaldo
			group by asutusId, rekvid, kuu, aasta, konto
	end
else
	begin
		declare  curKlSaldo  cursor 
		for select asutusId, rekvid, kuu, aasta, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select asutusId, library.rekvId, 0 as kuu, subkonto.aasta,library.kood as konto,
			subkonto.algsaldo as deebet, cast(0 as money) as kreedit from library inner join subkonto
			on library.id = subkonto.kontoid where subkonto.aasta = @aasta and library.rekvid = @rekvid
			union
			select curKaibed.asutusId1 as asutusId, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curasutuskaibed curkaibed 
				where kuu1 <= @Kuu and aasta1 = @aasta and rekvid1 = @rekvid) tmpSaldo
			where rekvid = @rekvid
			group by asutusid, rekvid, kuu, aasta, konto

	end

		open curKlSaldo


if @algkuu > 1
begin
select 'select 1', @algkuu as algkuu, @aasta as aasta, @rekvid as rekvid, @kuu as kuu0, asutusId, rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select asutusId, rekvid,  datepart(month,period) as kuu, datepart (year, period) as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 
			where datepart(month,period) < @algkuu 
			and datepart(year,period) = @aasta and rekvid = @rekvid
			union 
			select curkaibed.asutusid1 as asutusId, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curasutuskaibed curkaibed  where kuu1 >= @algkuu
				and kuu1 <= @Kuu and aasta1 = @aasta and rekvid1 = @rekvid )  tmpSaldo
			group by asutusId, rekvid, kuu, aasta, konto
end
else
select 'select 2',asutusId, rekvid, kuu, aasta, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select asutusId, library.rekvId, 0 as kuu, subkonto.aasta,library.kood as konto,
			subkonto.algsaldo as deebet, cast(0 as money) as kreedit from library inner join subkonto
			on library.id = subkonto.kontoid where subkonto.aasta = @aasta and library.rekvid = @rekvid
			union
			select curKaibed.asutusId1 as asutusId, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curasutuskaibed curkaibed 
				where kuu1 <= @Kuu and aasta1 = @aasta and rekvid1 = @rekvid) tmpSaldo
			where rekvid = @rekvid
			group by asutusid, rekvid, kuu, aasta, konto

		set @count = 0
		update saldo1 set saldo = 0,
			dbkaibed = 0,
			krkaibed = 0 
			where datepart (month,period ) = @kuu and datepart (year, period ) = @aasta and rekvid = @rekvid


		FETCH  curKlSaldo into @asutusId,  @rekvid, @kuu, @aasta, @konto, @deebet, @kreedit

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			if (@deebet <> 0 or @kreedit <> 0) and @asutusId <> 0
			begin
			set @count = @count + 1
			if @kuu = 0
				set @kuu = 1
			select @dbkaibed = deebet, @krkaibed = kreedit from curAsutusKaibed curKaibed 
				where asutusid1 = @asutusid and rekvid1 = @rekvId and kuu1 = @kuu and aasta1 = @aasta and konto1 = @konto
			if @@ROWCOUNT  = 0
				begin
					select @dbkaibed = 0, @krkaibed = 0
				end
			select  @asutusid as asutusid, @kuu as kuu, @aasta as aasta, @dbkaibed as dbkaibed, @krkaibed as krkaibed, @konto as konto, deebet, kreedit from curAsutusKaibed curKaibed 
				where asutusid1 = @asutusid and rekvid1 = @rekvId and kuu1 = @kuu and aasta1 = @aasta and konto1 = @konto
			select @dbkaibed = isnull (@dbkaibed,0), @krkaibed = isnull (@krkaibed,0)
			select @id = id from saldo1 where asutusid = @asutusid and konto = @konto 
				and datepart (month, period) = @kuu and datepart (year , period) = @aasta and rekvid = @rekvId
			if @@ROWCOUNT  = 0
				set @id = 0
			if @id = 0
				begin
					set @kpv = str (@aasta,4) + case  when @kuu < 10 then '0'+str (@kuu,1) when @kuu = 0 then '01' else str (@kuu,2)  end + '01'
					insert into saldo1 (rekvid, asutusid, period, konto, saldo, dbkaibed, krkaibed) 
						values (@rekvId, @asutusid, @kpv, @konto, @deebet - @kreedit, @dbkaibed, @krkaibed)
				end
			else
				begin
					update saldo1 set 
						saldo  = @deebet- @kreedit, 
						dbkaibed = @dbkaibed,
						krkaibed = @krkaibed	
						where id = @id										
				end 
			end	
		else
   			select @deebet = 0, @kreedit = 0, @asutusId = 0
			FETCH curKLSaldo into @asutusId, @rekvid, @kuu, @aasta, @konto, @deebet, @kreedit
		END

		CLOSE curKlSaldo
		DEALLOCATE curKlSaldo

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_kinniperiod]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_kinniperiod]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_klsaldo
@rekvId	int, 
@kuu 		int,
@aasta		int,
@konto		varchar (20),
@asutus	varchar (254)
AS
declare @algkuu	int
select top 1 @algkuu = kuu from aasta where kinni = 1 and aasta = @aasta order by kuu desc
set @algkuu = isnull (@algkuu, 0)
if @algkuu < @kuu and @algkuu > 0
	begin
		select asutusId, asutus, rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select asutusId, asutus.nimetus as asutus, saldo1.rekvid,  @kuu as kuu, @aasta as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 inner join asutus on asutus.id = saldo1.asutusid 
			where konto like @konto 
			and datepart(month,period) = @algKuu 
			and datepart (year, period) = @aasta
			and asutus.nimetus like @asutus
			union all
			select curkaibed.asutusId1 as asutusid, asutus.nimetus as asutus, curkaibed.rekvid1 as rekvid, @kuu as kuu, @aasta as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curAsutusKaibed curKaibed   inner join asutus on asutus.id = curkaibed.asutusId1 
 				where kuu1 > @algkuu
				and kuu1 < @Kuu and aasta1 = @aasta and konto1 like @konto and asutus.nimetus like @asutus)  tmpSaldo
			group by asutusid, asutus, rekvid,  kuu, aasta, konto

	end
if @algkuu = 0
	begin
		select asutusid, asutus, rekvid, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select subkonto.asutusId, asutus.nimetus as asutus, library.rekvId, @kuu as kuu, subkonto.aasta,library.kood as konto,
			subkonto.algsaldo as deebet, cast(0 as money) as kreedit from library inner join subkonto
			on library.id = subkonto.kontoid inner join asutus on asutus.id = subkonto.asutusid where subkonto.aasta = @aasta and library.kood like @konto and asutus.nimetus like @asutus
			union all
			select curkaibed.asutusid1 as asutusid, asutus.nimetus as asutus, curkaibed.rekvid1 as rekvid, @kuu as kuu,@aasta as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curAsutusKaibed curkaibed inner join asutus on asutus.id = curkaibed.asutusid1 
				where kuu1 < @Kuu and aasta1 = @aasta and asutus.nimetus like @asutus and konto1 like @konto) tmpSaldo
			group by asutusId, asutus, rekvid, kuu, aasta, konto


	end
if @algkuu >= @kuu and @kuu > 1
	begin
		set @algkuu = @kuu - 1
		select asutusId, asutus, rekvid, kuu, aasta, konto,  deebet, kreedit  from 
			(select asutusId, asutus.nimetus as asutus, saldo1.rekvid,  datepart(month,period) as kuu, datepart (year, period) as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 inner join asutus on asutus.id = saldo1.asutusid) tmpSaldo
		where konto like @konto
		and asutus like @asutus
		AND kuu = @algKuu and aasta = @aasta

	end

if @kuu = 1
	begin
		select asutusid, asutus, rekvid, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select subkonto.asutusId, asutus.nimetus as asutus, library.rekvId, 0 as kuu, subkonto.aasta,library.kood as konto,
			subkonto.algsaldo as deebet, cast(0 as money) as kreedit from library inner join subkonto
			on library.id = subkonto.kontoid inner join asutus on asutus.id = subkonto.asutusid where subkonto.aasta = @aasta)  tmpSaldo
			where konto like @konto
			and asutus like @asutus
			group by asutusId, asutus, rekvid, kuu, aasta, konto

	end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_klsaldo]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_klsaldo]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE sp_klsaldo1
@rekvId	int, 
@kuu 		int,
@aasta		int,
@konto		varchar (20),
@asutus	varchar (254)
AS
declare @algkuu	int
select top 1 @algkuu = kuu from aasta where kinni = 1 and aasta = @aasta order by kuu desc
set @algkuu = isnull (@algkuu, 0)
select @algkuu, @kuu, @aasta
if @algkuu < @kuu and @algkuu > 0
	begin

		select rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select asutusId, asutus.nimetus as asutus, saldo1.rekvid,  @kuu as kuu, @aasta as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 inner join asutus on asutus.id = saldo1.asutusid 
			where konto like @konto 
			and datepart(month,period) = @algKuu 
			and datepart (year, period) = @aasta
			and asutus.nimetus like @asutus
			union 
			select curkaibed.asutusId1 as asutusid, asutus.nimetus as asutus, curkaibed.rekvid1 as rekvid, @kuu as kuu, @aasta as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curAsutusKaibed curKaibed   inner join asutus on asutus.id = curkaibed.asutusId1 
 				where kuu1 > @algkuu
				and kuu1 < @Kuu and aasta1 = @aasta and konto1 like @konto and asutus.nimetus like @asutus)  tmpSaldo
			group by rekvid,  kuu, aasta, konto

	end
if @algkuu = 0
	begin
		select asutusid, asutus, rekvid, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select subkonto.asutusId, asutus.nimetus as asutus, library.rekvId, 0 as kuu, subkonto.aasta,library.kood as konto,
			subkonto.algsaldo as deebet, cast(0 as money) as kreedit from library inner join subkonto
			on library.id = subkonto.kontoid inner join asutus on asutus.id = subkonto.asutusid where subkonto.aasta = @aasta
			union
			select curkaibed.asutusid1 as asutusid, asutus.nimetus as asutus, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curAsutusKaibed curkaibed inner join asutus on asutus.id = curkaibed.asutusid1 
				where kuu1 <= @Kuu and aasta1 = @aasta) tmpSaldo
			where konto like @konto
			and asutus like @asutus
			group by asutusId, asutus, rekvid, kuu, aasta, konto


	end
if @algkuu >= @kuu
	begin
		set @algkuu = @kuu
		select asutusId, asutus, rekvid, kuu, aasta, konto,  deebet, kreedit  from 
			(select asutusId, asutus.nimetus as asutus, saldo1.rekvid,  datepart(month,period) as kuu, datepart (year, period) as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 inner join asutus on asutus.id = saldo1.asutusid) tmpSaldo
		where konto like @konto
		and asutus like @asutus
		AND kuu = @algKuu and aasta = @aasta

	end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_klsaldo_intproc
@rekvId	int, 
@kuu 		int,
@aasta		int,
@curKlSaldo CURSOR VARYING OUTPUT
AS
declare @algkuu	int
select top 1 @algkuu = kuu from aasta where kinni = 1 and aasta = @aasta order by kuu desc
set @algkuu = isnull (@algkuu, 0)
if @algkuu < @kuu and @algkuu > 0
	begin
		SET @curKlSaldo = CURSOR FORWARD_ONLY STATIC FOR
		select asutusId, rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select asutusId, rekvid, konto, datepart(month,period) as kuu, datepart (year, period) as aasta,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 
			union 
			select curkaibed.asutusid1 as asutusId, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curasutuskaibed curkaibed  where kuu1 > @algkuu
				and kuu1 <= @Kuu and aasta1 = @aasta )  tmpSaldo
			where kuu = @algKuu and aasta = @aasta
			group by asutusId, rekvid, kuu, aasta, konto

	end
if @algkuu = 0
	begin
		SET @curKlSaldo = CURSOR FORWARD_ONLY STATIC FOR
		select asutusId, rekvid, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select asutusId, library.rekvId, 0 as kuu, subkonto.aasta,library.kood as konto,
			subkonto.algsaldo as deebet, cast(0 as money) as kreedit from library inner join subkonto
			on library.id = subkonto.kontoid where subkonto.aasta = @aasta
			union
			select curKaibed.asutusId1 as asutusId, curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curasutuskaibed curkaibed where kuu1 <= @Kuu and aasta1 = @aasta) tmpSaldo
			group by asutusid, rekvid, kuu, aasta, konto



	end
if @algkuu >= @kuu
	begin
		set @algkuu = @kuu
		SET @curKlSaldo = CURSOR FORWARD_ONLY STATIC FOR
		select asutusId, rekvid, kuu, aasta, konto,  deebet, kreedit  from 
			(select asutusId, rekvid, konto, datepart(month,period) as kuu, datepart (year, period) as aasta,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo1 ) tmpSaldo
		where kuu = @algKuu and aasta = @aasta

	end
open @curKlSaldo

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_klsaldo_intproc]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_klsaldo_intproc]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_recalc_saldo 
	@rekvId	int,
	@kpv1	datetime,
	@kpv2	datetime,
	@pohikonto	varchar ( 20 )
AS
declare 	@id	int,
	@dbkaibed	money,
	@krkaibed	money,
	@saldo		money,
	@period	datetime,
	@lastsaldo	money,
	@viimanekonto varchar ( 20 ),
	@count int,
	@aasta	int,
	@konto	varchar( 20 )
set @lastsaldo = 0
set @viimanekonto = space (1)
declare cur_saldod cursor
for select   id, konto,period, saldo, dbkaibed, krkaibed   
	from saldo 
	where rekvid = @rekvid
	and datepart (year, period ) >= datepart ( year, @kpv1 )
	and datepart (month, period ) >= datepart ( month, @kpv1 )
	and datepart (year, period ) <= datepart ( year, @kpv2 )
	and datepart (month, period ) <= datepart ( month, @kpv2 )	
	and konto like @pohikonto
	order by saldo.konto, period
set @count = 0
open cur_saldod
fetch cur_saldod into @id, @konto, @period, @saldo, @dbkaibed, @krkaibed
while @@fetch_status = 0
begin
	if @viimanekonto <> @konto
		begin
			set @count = 1
			set @lastsaldo = @saldo
		end
	update saldo set saldo = @lastsaldo where id = @id
	select @lastsaldo =  @lastsaldo + @dbkaibed - @krkaibed, @viimanekonto = @konto	
	set @count = @count + 1
	fetch cur_saldod into @id, @konto, @period, @saldo, @dbkaibed, @krkaibed
end
close cur_saldod
deallocate cur_saldod
set @aasta = datepart (year, @kpv1 )
exec sp_update_pohikonto_saldo @rekvid, @aasta, 0 , @pohikonto
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_recalc_saldo]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_recalc_saldo]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_recalc_saldo1 
	@rekvId	int,
	@kpv1	datetime,
	@kpv2	datetime,
	@pohikonto	varchar ( 20 )
AS

declare 	@id	int,
	@dbkaibed	money,
	@krkaibed	money,
	@saldo		money,
	@period	datetime,
	@lastsaldo	money,
	@viimanekonto varchar ( 20 ),
	@count int,
	@aasta	int,
	@konto	varchar( 20 ),
	@asutusid	int,
	@viimaneasutus	int

set @lastsaldo = 0
set @viimanekonto = space (1)
set @viimaneasutus = 0

declare cur_subkonto cursor
for select distinct asutusid from subkonto inner join library on library.id = subkonto.kontoId 
	where library.rekvid = @rekvId
	and subkonto.aasta = datepart ( year, @kpv1) 
	and library.kood like @pohikonto
	order by asutusId 

open cur_subkonto
fetch cur_subkonto into @asutusId
while @@fetch_status = 0
begin

	declare cur_saldod cursor
		for select   id, konto, period, saldo, dbkaibed, krkaibed   
		from saldo1 
		where rekvid = @rekvid
		and datepart (year, period ) >= datepart ( year, @kpv1 )
		and datepart (month, period ) >= datepart ( month, @kpv1 )
		and datepart (year, period ) <= datepart ( year, @kpv2 )
		and datepart (month, period ) <= datepart ( month, @kpv2 )	
		and asutusid = @asutusId
		order by asutusid, saldo1.konto, period
	set @count = 0
	open cur_saldod
	fetch cur_saldod into @id, @konto, @period, @saldo, @dbkaibed, @krkaibed
	while @@fetch_status = 0
	begin

		if @viimanekonto <> @konto or @viimaneAsutus <> @asutusId
			begin
				set @count = 1
				set @lastsaldo = @saldo
			end
		update saldo1 set saldo = @lastsaldo where id = @id
		select @lastsaldo =  @lastsaldo + @dbkaibed - @krkaibed, @viimanekonto = @konto, @viimaneasutus = @asutusId	
		set @count = @count + 1
		fetch cur_saldod into @id, @konto, @period, @saldo, @dbkaibed, @krkaibed
	end
	close cur_saldod
	deallocate cur_saldod
	set @lastsaldo = 0
	fetch cur_subkonto into @asutusId
end
close cur_subkonto
deallocate cur_subkonto
set @aasta = datepart (year, @kpv1 )
exec sp_update_pohikonto_saldo1 @rekvid, @aasta, 0, @pohikonto		













GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_recalc_saldo1]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_recalc_saldo1]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_recalc_saldo2
	@rekvId	int,
	@kpv1	datetime,
	@kpv2	datetime,
	@pohikonto	varchar ( 20 ),
	@asutus	int
AS
declare 	@id	int,
	@asutusId	int,
	@dbkaibed	money,
	@krkaibed	money,
	@saldo		money,
	@period	datetime,
	@lastsaldo	money,
	@viimanekonto varchar ( 20 ),
	@count int,
	@aasta	int,
	@konto	varchar( 20 ),
	@viimaneasutus	int
set @lastsaldo = 0
set @viimanekonto = space (1)
set @viimaneasutus = 0
declare cur_subkonto cursor
for select distinct asutusid from subkonto inner join library on library.id = subkonto.kontoId 
	where library.rekvid = @rekvId
	and subkonto.aasta = datepart ( year, @kpv1) 
	and library.kood like @pohikonto
	and asutusId = @asutus
	order by asutusId 
open cur_subkonto
fetch cur_subkonto into @asutusId
while @@fetch_status = 0
begin
	declare cur_saldod cursor
		for select   id, konto, period, saldo, dbkaibed, krkaibed   
		from saldo1 
		where rekvid = @rekvid
		and datepart (year, period ) >= datepart ( year, @kpv1 )
		and datepart (month, period ) >= datepart ( month, @kpv1 )
		and datepart (year, period ) <= datepart ( year, @kpv2 )
		and datepart (month, period ) <= datepart ( month, @kpv2 )	
		and asutusid = @asutusId
		order by asutusid, saldo1.konto, period
	set @count = 0
	open cur_saldod
	fetch cur_saldod into @id, @konto, @period, @saldo, @dbkaibed, @krkaibed
	while @@fetch_status = 0
	begin
		if @viimanekonto <> @konto or @viimaneAsutus <> @asutusId
			begin
				set @count = 1
				set @lastsaldo = @saldo
			end
		update saldo1 set saldo = @lastsaldo where id = @id
		select @lastsaldo =  @lastsaldo + @dbkaibed - @krkaibed, @viimanekonto = @konto, @viimaneasutus = @asutusId	
		set @count = @count + 1
		fetch cur_saldod into @id, @konto, @period, @saldo, @dbkaibed, @krkaibed
	end
	close cur_saldod
	deallocate cur_saldod
	set @lastsaldo = 0
	fetch cur_subkonto into @asutusId
end
close cur_subkonto
deallocate cur_subkonto
set @aasta = datepart (year, @kpv1 )
exec sp_update_pohikonto_saldo1 @rekvid, @aasta, 0, @pohikonto
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_recalc_saldo2]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_recalc_saldo2]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_saldo
@rekvId	int, 
@kuu 		int,
@aasta		int,
@konto		varchar (20)
AS
declare @algkuu	int
select top 1 @algkuu = kuu from aasta where kinni = 1 and aasta = @aasta order by kuu desc
set @algkuu = isnull (@algkuu, 0)
if @algkuu < @kuu and @algkuu > 0
	begin
		select rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select rekvid, @kuu  as kuu, @aasta as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo where konto like @konto and rekvId = @rekvid  
			and datepart(month,period) = @algKuu and  datepart (year, period) = @aasta
			union all
			select curkaibed.rekvid1 as rekvid, @kuu as kuu, @aasta as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed  where kuu1 > @algkuu
				and kuu1 < @Kuu and aasta1 = @aasta and rekvid1 = @rekvid and konto1 like @konto)  tmpSaldo
			where konto like @konto 
			group by rekvid, kuu, aasta, konto

	end
if @kuu = 1 
	begin
/*		select rekvid, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select library.rekvId, 0 as kuu, kontoinf.aasta,library.kood as konto,
			kontoinf.algsaldo as deebet, cast(0 as money) as kreedit from library inner join kontoinf
			on library.id = kontoinf.parentid where kontoinf.aasta = @aasta and rekvid = @rekvid and kood like @konto
			union
			select curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed where kuu1 <= @Kuu 
				and aasta1 = @aasta and rekvid1 = @rekvid and konto1 like @konto) tmpSaldo
			where konto like @konto
			group by rekvid, kuu, aasta, konto
*/
	select rekvid, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select library.rekvId, 0 as kuu, kontoinf.aasta,library.kood as konto,
			"deebet "= 
			case when kontoinf.algsaldo >= 0 then kontoinf.algsaldo else 0   end,
			"kreedit "=  
			case when kontoinf.algsaldo < 0 then -1 * kontoinf.algsaldo else 0   end
			from library inner join kontoinf
			on library.id = kontoinf.parentid where kontoinf.aasta = @aasta and rekvid = @rekvid and kood like @konto) tmpSaldo
			group by rekvid, kuu, aasta, konto


	end
if @algkuu > @kuu and @algkuu > 1 and @kuu > 1
	begin
		set @algkuu = @kuu - 1
		select rekvid, konto, datepart(month,period) as kuu, datepart (year, period) as aasta,
		"deebet " = case when (saldo + dbkaibed - krKaibed) >= 0 then saldo + dbkaibed - krKaibed else cast(0 as money) end, 
		"kreedit " = case when (saldo + dbkaibed - krKaibed) < 0 then krKaibed - (saldo + dbkaibed)  else cast(0 as money) end 
		from saldo  where rekvid = @rekvid 
		and konto like @konto
		AND datepart(month,period) = @algKuu 
		and datepart (year, period) = @aasta

	end
if @algkuu = @kuu and @algkuu > 0
	begin
		set @algkuu = @kuu - 1
		select rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select rekvid, @kuu  as kuu, @aasta as aasta, konto,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo where konto like @konto and rekvId = @rekvid  
			and datepart(month,period) = @algKuu and  datepart (year, period) = @aasta
			union 
			select curkaibed.rekvid1 as rekvid, @kuu as kuu, @aasta as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed  where kuu1 > @algkuu
				and kuu1 < @Kuu and aasta1 = @aasta and rekvid1 = @rekvid and konto1 like @konto)  tmpSaldo
			where konto like @konto 
			group by rekvid, kuu, aasta, konto

	end
if @kuu > 1 and @algkuu = 0 
	begin
	select rekvid, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select library.rekvId, @kuu as kuu, kontoinf.aasta,library.kood as konto,
			"deebet "= 
			case when kontoinf.algsaldo >= 0 then kontoinf.algsaldo else 0   end,
			"kreedit "=  
			case when kontoinf.algsaldo < 0 then -1 * kontoinf.algsaldo else 0   end
			from library inner join kontoinf
			on library.id = kontoinf.parentid where kontoinf.aasta = @aasta and rekvid = @rekvid and kood like @konto	
			union all
			select curkaibed.rekvid1 as rekvid, @kuu as kuu, @aasta as aasta, curkaibed.konto1 as konto, curKaibed.deebet,curKaibed.kreedit
			 from curkaibed where kuu1 < @Kuu 
			and aasta1 = @aasta and rekvid1 = @rekvid and konto1 like @konto) tmpSaldo
			group by rekvid, kuu, aasta, konto


	end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_saldo]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_saldo]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE sp_saldo_intproc
@rekvId	int, 
@kuu 		int,
@aasta		int,
@curSaldo CURSOR VARYING OUTPUT
AS
declare @algkuu	int
select top 1 @algkuu = kuu from aasta where kinni = 1 and aasta = @aasta order by kuu desc
set @algkuu = isnull (@algkuu, 0)
if @algkuu < @kuu and @algkuu > 0
	begin
		SET @curSaldo = CURSOR FORWARD_ONLY STATIC FOR
		select rekvid, kuu, aasta, konto,  sum(deebet) as deebet, sum(kreedit) as kreedit from 
			(select rekvid, konto, datepart(month,period) as kuu, datepart (year, period) as aasta,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo 
			union 
			select curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed  where kuu1 > @algkuu
				and kuu1 <= @Kuu and aasta1 = @aasta )  tmpSaldo
			where kuu = @algKuu and aasta = @aasta
			group by rekvid, kuu, aasta, konto

	end
if @algkuu = 0
	begin
		SET @curSaldo = CURSOR FORWARD_ONLY STATIC FOR
		select rekvid, kuu, aasta, konto, sum(deebet) as deebet,  sum(kreedit) as kreedit from
			(select library.rekvId, 0 as kuu, kontoinf.aasta,library.kood as konto,
			kontoinf.algsaldo as deebet, cast(0 as money) as kreedit from library inner join kontoinf
			on library.id = kontoinf.parentid where kontoinf.aasta = @aasta
			union
			select curkaibed.rekvid1 as rekvid, curkaibed.kuu1 as kuu, curKaibed.aasta1 as aasta,
				curkaibed.konto1 as konto, curKaibed.deebet, curKaibed.kreedit from curkaibed where kuu1 <= @Kuu and aasta1 = @aasta) tmpSaldo
			group by rekvid, kuu, aasta, konto


	end
if @algkuu >= @kuu
	begin
		set @algkuu = @kuu
		SET @curSaldo = CURSOR FORWARD_ONLY STATIC FOR
		select rekvid, kuu, aasta, konto,  deebet, kreedit  from 
			(select rekvid, konto, datepart(month,period) as kuu, datepart (year, period) as aasta,
			saldo + dbkaibed - krKaibed as deebet, cast(0 as money) as kreedit from saldo ) tmpSaldo
		where kuu = @algKuu and aasta = @aasta
	end
open @curSaldo

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_saldo_intproc]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_saldo_intproc]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_save_copy 
@tnId	int
AS
declare 	@id	int,
	@rekvId	int,
	@kpv	datetime,	
	@asutusid int,
	@parentId	int,
	@lausendId	int,
	@deebet	varchar(20), 
	@kreedit	varchar(20),
	@kood1	int,
	@kood2	int, 
	@kood3	int, 
	@kood4	int, 
	@summa money,
	@copyid	int


declare cur_koopia cursor
for select   id, rekvId, kpv, asutusid  
	from journal  
	where id = @tnId
declare cur_koopia1 cursor
for select   parentid, lausendId, deebet, kreedit, kood1, kood2, kood3, kood4, summa
	from journal1  inner join lausend on lausendId = lausend.Id
	where Parentid = @tnId

open cur_koopia
fetch cur_koopia into @id, @rekvId, @kpv, @asutusId
while @@fetch_status = 0
begin
	set @id = isnull(@id,0)
	if @id > 0
		begin 
			insert into journalTmp (id, rekvid, kpv, asutusId)
				values (@id, @rekvId, @kpv, @asutusId)
			select top 1 @copyId = copyid from journalTmp order by copyid desc
		end
	fetch cur_koopia into @id, @rekvId, @kpv, @asutusId
end
close cur_koopia
deallocate cur_koopia
open cur_koopia1
fetch cur_koopia1 into @parentid, @LausendId, @deebet, @kreedit, @kood1, @kood2, @kood3, @kood4, @summa
while @@fetch_status = 0
begin
	insert into journal1Tmp (copyid,  parentId, deebet, kreedit, kood1, kood2, kood3, kood4, summa)
		values (@copyid, @parentId, @deebet, @kreedit, @kood1, @kood2, @kood3, @kood4, @summa)
	fetch cur_koopia1 into @parentid, @LausendId, @deebet, @kreedit, @kood1, @kood2, @kood3, @kood4, @summa
end
close cur_koopia1
deallocate cur_koopia1
select 'copyId' = @copyId
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_save_copy]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_save_copy]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE sp_update_palk_jaak 
@dKpv1	datetime,
@dKpv2	datetime,
@gRekvId	int,
@lepingId	int

AS
declare 		@Arv		money,
		@Kinni		money,
		@Tulumaks	money,
		@Sotsmaks	money,	
		@Id		int,
		@Kuu1		smallint,
		@Kuu2		smallint,
		@Aasta1	smallint,
		@Aasta2	smallint

select @kuu1 = datepart  ( month, @dKpv1),  @kuu2 = datepart  ( month, @dKpv2),  @Aasta1 = datepart  ( year, @dKpv1),  @Aasta2 = datepart  ( year, @dKpv2)

SELECT @Arv =  sum( Palk_oper.summa )
FROM Library inner join Palk_lib on library.id = palk_lib.parentid 
inner join Palk_oper on library.id = palk_oper.libid 
WHERE Palk_lib.liik = 1    
AND Palk_oper.kpv >= @dKpv1   
AND Palk_oper.kpv <= @dKpv2
AND Palk_oper.rekvId = @gRekvId
AND palk_oper.lepingId	= @LepingId
set @Arv = isnull (@Arv,0)

SELECT @Kinni =  sum( Palk_oper.summa )
FROM Library inner join Palk_lib on library.id = palk_lib.parentid 
inner join Palk_oper on library.id = palk_oper.libid 
WHERE (Palk_lib.liik = 2    or palk_lib.liik = 8 or palk_lib.liik = 6 or (palk_lib.liik = 7 and palk_lib.asutusest = 0))
AND Palk_oper.kpv >= @dKpv1   
AND Palk_oper.kpv <= @dKpv2
AND Palk_oper.rekvId = @gRekvId
AND palk_oper.lepingId	= @LepingId
set @Kinni = isnull (@Kinni,0)

SELECT @Tulumaks =  sum( Palk_oper.summa )
FROM Library inner join Palk_lib on library.id = palk_lib.parentid 
inner join Palk_oper on library.id = palk_oper.libid 
WHERE Palk_lib.liik = 4    
AND Palk_oper.kpv >= @dKpv1   
AND Palk_oper.kpv <= @dKpv2
AND Palk_oper.rekvId = @gRekvId
AND palk_oper.lepingId	= @LepingId
set @Tulumaks = isnull (@Tulumaks,0)

SELECT @Sotsmaks =  sum( Palk_oper.summa )
FROM Library inner join Palk_lib on library.id = palk_lib.parentid 
inner join Palk_oper on library.id = palk_oper.libid 
WHERE Palk_lib.liik = 5
AND Palk_oper.kpv >= @dKpv1   
AND Palk_oper.kpv <= @dKpv2
AND Palk_oper.rekvId = @gRekvId
AND palk_oper.lepingId	= @LepingId
set @Sotsmaks = isnull (@Sotsmaks,0)

select @Id = id from palk_jaak 
where lepingId = @lepingId 
and kuu = @kuu1
and aasta = @aasta1
set @id = isnull(@id,0)

if @id = 0
	insert into palk_jaak ( lepingId, kuu, aasta, arvestatud, kinni, tulumaks, sotsmaks)
		values (@lepingId, @kuu1, @aasta1, @arv, @kinni, @tulumaks, @sotsmaks)
else
	update palk_jaak set 
		arvestatud = @arv,
		kinni = @kinni,
		tulumaks = @tulumaks,
		sotsmaks = @sotsmaks
		where id = @id

exec sp_calc_palk_jaak @Kuu1, @aasta1, @lepingId






GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_update_palk_jaak]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_update_palk_jaak]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_update_pohikonto_saldo 
@rekvid	int,
@aasta		int,
@kuu		int,
@konto		varchar ( 20 )
AS
declare @kood		varchar ( 20),
	@saldo		money,
	@krkaibed	money,
	@dbkaibed	money,
	@period		varchar ( 20 ),
	@kuu1		int,
	@kuu2		int
if @kuu = 0
	select @kuu1 = 1, @kuu2 = 12
else
	select @kuu1 = @kuu,  @kuu2 = @kuu

declare cur_pohikonto cursor
for select kood 
	from library inner join kontoinf on kontoinf.parentid = library.id 
	where liik = 2
	and library.kood like @konto
	and library.rekvid = @rekvId
	select kood 
	from library inner join kontoinf on kontoinf.parentid = library.id 
	where liik = 2
	and library.kood like @konto
	and library.rekvid = @rekvId

open cur_pohikonto
fetch cur_pohikonto into @kood
while @@fetch_status = 0
begin
	declare cur_kaibed cursor
		for  select str ( datepart ( year, period), 4) + str ( datepart (month, period ),2 ) period,
		sum ( saldo ) saldo, sum ( dbkaibed ) dbkaibed, sum (krkaibed ) krkaibed 
		from saldo inner join library on library.kood = saldo.konto
		inner join kontoinf on kontoinf.parentId = library.id
		where library.library = 'KONTOD'
		and kontoinf.pohikonto = @kood
		and saldo.rekvid = @rekvid
		and datepart ( year, period ) = @aasta
		and datepart ( month, period ) >= @kuu1
		and datepart ( month, period ) <= @kuu2
		group by str ( datepart ( year, period), 4) + str ( datepart (month, period ),2 )
		order by str ( datepart ( year, period), 4) + str ( datepart (month, period ),2 )


	open cur_kaibed
	fetch cur_kaibed into @period, @saldo, @dbkaibed, @krkaibed
	while @@fetch_status = 0
		begin
			update saldo set saldo = @saldo, 
				dbkaibed = @dbkaibed,
				krkaibed = @krkaibed
				where konto = @kood
				and str ( datepart ( year, period ),4 ) + str ( datepart (month, period ),2 )= @period  
				and saldo.rekvid = @rekvid
			fetch cur_kaibed into @period, @saldo, @dbkaibed, @krkaibed
		end
	close cur_kaibed
	deallocate cur_kaibed


	fetch cur_pohikonto into @kood
end
close cur_pohikonto
deallocate cur_pohikonto
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_update_pohikonto_saldo]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_update_pohikonto_saldo]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE sp_update_pohikonto_saldo1 
@rekvid	int,
@aasta		int,
@kuu		int,
@konto		varchar ( 20 )
AS
declare @kood		varchar ( 20),
	@saldo		money,
	@krkaibed	money,
	@dbkaibed	money,
	@period	varchar ( 20 ),
	@asutusId	int,
	@kuu1		int,
	@kuu2		int

if @kuu = 0
		select @kuu1 = 1, @kuu2 = 12
else
		select @kuu1 = @kuu,  @kuu2 = @kuu

declare cur_pohikonto cursor
for select kood, subkonto.asutusid
	from library inner join kontoinf on kontoinf.parentid = library.id 
	inner join subkonto on subkonto.kontoid = library.id
	where liik = 2
	and library.kood like @konto
	and library.rekvid = @rekvId

open cur_pohikonto
fetch cur_pohikonto into @kood, @asutusId
while @@fetch_status = 0
begin
	declare cur_kaibed cursor
		for  select str ( datepart ( year, period), 4) + str ( datepart (month, period ),2 ) period,
		sum ( saldo ) saldo, sum ( dbkaibed ) dbkaibed, sum (krkaibed ) krkaibed 
		from saldo1 inner join library on library.kood = saldo1.konto
		inner join kontoinf on kontoinf.parentId = library.id
		where library.library = 'KONTOD'
		and kontoinf.pohikonto = @kood
		and saldo1.asutusId = @asutusId
		and saldo1.rekvid = @rekvid
		and datepart ( year, period ) = @aasta
		and datepart ( month, period) >= @kuu1
		and datepart ( month, period ) <= @kuu2
		group by str ( datepart ( year, period), 4) + str ( datepart (month, period ),2 )
		order by str ( datepart ( year, period), 4) + str ( datepart (month, period ),2 )


	open cur_kaibed
	fetch cur_kaibed into @period, @saldo, @dbkaibed, @krkaibed
	while @@fetch_status = 0
		begin
			update saldo1 set saldo = @saldo, 
				dbkaibed = @dbkaibed,
				krkaibed = @krkaibed
				where konto = @kood
				and str ( datepart ( year, period ),4 ) + str ( datepart (month, period ),2 )= @period  
				and saldo1.rekvid = @rekvid
			fetch cur_kaibed into @period, @saldo, @dbkaibed, @krkaibed
		end
	close cur_kaibed
	deallocate cur_kaibed


	fetch cur_pohikonto into @kood
end
close cur_pohikonto
deallocate cur_pohikonto
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_update_pohikonto_saldo1]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_update_pohikonto_saldo1]  TO [dbkasutaja]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE sp_update_saldo 
@CopyId	int, 
@Id		int
AS
declare 	@asutusId	int,
	@rekvId	int,
	@lausendId	int,
	@deebet	char(20),
	@kreedit	char(20),
	@summa		money,
	@month		smallint,
	@year		smallint,
	@kpv		datetime,
	@today		datetime,
	@month1	smallint,
	@year1		smallint,
	@lSaldo	money,
	@dbKaibed 	money,
	@krkaibed	money,
	@sId		int,
	@kontoid	int
	declare @nMonth int,
		@cMonth	varchar(20),
		@dkpv	datetime,
		@nid	int
declare cur_backlaus cursor
for select  kpv, asutusid,  lausendId, deebet, kreedit, summa , rekvid 
	from journalTmp inner join journal1Tmp on journalTmp.copyid = journal1Tmp.copyid  
	where journalTmp.copyid = @CopyId
open cur_backlaus
fetch cur_backlaus into @kpv, @asutusId, @lausendid, @deebet, @kreedit, @summa, @rekvId
while @@fetch_status = 0
begin
	set @today = getdate()	
	set @today = dateadd ( month,1,@today)
	select @month = datepart(month, @kpv), @year = datepart (year,@kpv)
	update saldo set dbkaibed  = dbkaibed - @summa
		where datepart(year,period) = @year
		and datepart (month, period) = @month
		and konto = @deebet
	exec  sp_recalc_saldo 	@rekvId, @kpv, @today , @deebet 
	if @asutusId > 0
		begin
			select @id = id from library where kood = @deebet and library = 'KONTOD' and rekvid = @rekvid
			set @id = isnull(@id,0)
			exec sp_check_subkonto  @id, @asutusId
			update saldo1 set dbkaibed  = dbkaibed - @summa
				where datepart(year,period) = @year
				and datepart (month, period) = @month
				and konto = @deebet
				and asutusId = @asutusId
			exec  sp_recalc_saldo2 	@rekvId, @kpv, @today , @deebet, @AsutusId 
		end
	update saldo set krkaibed  = krkaibed - @summa
		where datepart(year,period) = @year
		and datepart (month, period) = @month
		and konto = @kreedit
	exec  sp_recalc_saldo 	@rekvId, @kpv, @today , @kreedit 
	if @asutusId > 0
		begin

			update saldo1 set krkaibed  = krkaibed - @summa
				where datepart(year,period) = @year
				and datepart (month, period) = @month
				and konto = @kreedit
				and asutusId = @asutusId
			exec  sp_recalc_saldo2 	@rekvId, @kpv, @today , @kreedit, @AsutusId 
		end
	fetch cur_backlaus into @kpv, @asutusId, @lausendid, @deebet, @kreedit, @summa, @rekvid
end
delete from journalTmp where copyid = @copyId
delete from journal1Tmp where copyid = @copyId
close cur_backlaus
deallocate cur_backlaus
declare cur_laus cursor
for select  journal.kpv, journal.asutusid,  journal1.lausendId, lausend.deebet, lausend.kreedit, journal1.summa  , journal.rekvId
	from journal inner join journal1 on journal.id = journal1.parentid  
	inner join lausend on lausend.Id = journal1.lausendid 
	where journal.id = @Id
open cur_laus
fetch cur_laus into @kpv, @asutusId, @lausendid, @deebet, @kreedit, @summa, @rekvId
while @@fetch_status = 0
begin
	select @month = datepart(month, @kpv), @year = datepart (year,@kpv)
	update saldo set dbkaibed  = dbkaibed + @summa
		where datepart(year,period) = @year
		and datepart (month, period) = @month
		and konto = @deebet
		and rekvId =@rekvId
	exec  sp_recalc_saldo 	@rekvId, @kpv, @today , @deebet
	if @asutusId > 0
		begin
			select @id = id from library where kood = @deebet and library = 'KONTOD' and rekvid = @rekvid
			exec sp_check_subkonto @id, @asutusId						
			update saldo1 set dbkaibed  = dbkaibed + @summa
				where datepart(year,period) = @year
				and datepart (month, period) = @month
				and konto = @deebet
				and asutusId = @asutusId
			exec  sp_recalc_saldo2 	@rekvId, @kpv, @today , @deebet, @AsutusId 
		end
	update saldo set krkaibed  = krkaibed + @summa
		where datepart(year,period) = @year
		and datepart (month, period) = @month
		and konto = @kreedit
		and rekvId =@rekvId
	exec  sp_recalc_saldo 	@rekvId, @kpv, @today , @kreedit 
	if @asutusId > 0
		begin
			select @id = id from library where kood = @Kreedit and library = 'KONTOD' and rekvid = @rekvid
			exec sp_check_subkonto @id, @asutusId									 
			update saldo1 set krkaibed  = krkaibed + @summa
				where datepart(year,period) = @year
				and datepart (month, period) = @month
				and konto = @kreedit
				and asutusId = @asutusId
			exec  sp_recalc_saldo2 	@rekvId, @kpv, @today , @kreedit, @AsutusId 
		end
	fetch cur_laus into @kpv, @asutusId, @lausendid, @deebet, @kreedit, @summa, @rekvId
end
close cur_laus
deallocate cur_laus

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[sp_update_saldo]  TO [dbpeakasutaja]
GO

GRANT  EXECUTE  ON [dbo].[sp_update_saldo]  TO [dbkasutaja]
GO

